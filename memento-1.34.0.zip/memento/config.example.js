// Example settings. Copy this file to config.js, fill in your own details, and reload the new tab.
// config.js is git-ignored, so your personal details never get committed.
window.MEMENTO_CONFIG = {
  name: "",                      // shown in the greeting; leave empty for none
  birthday: "2000-01-01",        // YYYY-MM-DD
  lifeYears: 80,                 // grid is lifeYears x 52 weeks
  notionUrl: "https://www.notion.so",                    // your Notion home page
  pinterestUrl: "https://www.pinterest.com/",
  meetLink: "https://calendar.notion.com/meet/your-name/meet",   // copied by "Copy meeting link" (or press M)
  notionCalendarUrl: "https://calendar.notion.so",
  calendarIcsUrls: [],           // optional: secret iCal links; you can also paste them on the page
  clock24h: false,               // true = 24-hour clock
  maxQuoteLength: 160,
  cities: [
    { label: "New York", zone: "America/New_York" },
    { label: "London",   zone: "Europe/London" },
    { label: "Tokyo",    zone: "Asia/Tokyo" }
  ],
  // Add more images to /assets and list them here. "position" is the CSS background-position.
  backgrounds: [
    { file: "assets/clouds.webp", position: "center 45%" }
  ],
  // Retro pan: the picture updates only `fps` times a second and holds still in between.
  retro: {
    fps: 6,            // 6 = one change every 10 frames on a 60Hz screen
    panSeconds: 684,    // time to pan one way before reversing (higher = slower)
    weavePx: 1,        // random film-gate jitter per step
    flicker: 0.02      // random brightness change per step (0 = off)
  }
};
