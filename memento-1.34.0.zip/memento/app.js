(() => {
  "use strict";
  const C = window.MEMENTO_CONFIG;
  const $ = (id) => document.getElementById(id);
  const DAY = 864e5;

  // ---------- small storage helpers ----------
  const local = {
    get(key, fallback) { try { const v = localStorage.getItem("memento:" + key); return v == null ? fallback : JSON.parse(v); } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem("memento:" + key, JSON.stringify(value)); } catch {} }
  };
  const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync;
  const syncStore = {
    async get(key) {
      if (!hasChrome) return local.get(key, null);
      const s = await chrome.storage.sync.get(key);
      if (s[key] !== undefined) return s[key];
      const l = await chrome.storage.local.get(key);   // fallback copy if sync quota was ever hit
      return l[key] !== undefined ? l[key] : null;
    },
    async set(key, value) {
      if (!hasChrome) return local.set(key, value);
      try { await chrome.storage.sync.set({ [key]: value }); }
      catch (e) { await chrome.storage.local.set({ [key]: value }); }
    }
  };

  const toast = window.mementoToast = (msg) => {
    const t = $("toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toast.timer); toast.timer = setTimeout(() => t.classList.remove("show"), 1400);
  };

  // ---------- locked layout height ----------
  // Chrome can slide its own footer in after the page loads, which makes the visible area shorter.
  // The layout is sized from the tallest height ever seen for this window size instead, and keeps room
  // for the footer once it has been seen, so nothing moves when it appears or disappears.
  const root = document.documentElement;
  let lockedFor = "";
  function lockHeight() {
    const key = `layoutH:${outerWidth}x${outerHeight}`;
    const s = local.get(key, { h: 0 });
    const h = Math.max(innerHeight, s.h || 0);
    const f = 44;                                         // fixed room at the bottom for Chrome's footer, shown or not,
                                                          // so every tab lays out exactly the same (no learning, no drift)
    if (h !== s.h) local.set(key, { h });
    if (lockedFor === key) return false;                  // same window: never re-fit the current tab
    lockedFor = key;
    root.style.setProperty("--H", h + "px");
    root.style.setProperty("--vu", (h / 100).toFixed(3) + "px");
    root.style.setProperty("--footer", f + "px");
    return true;
  }
  lockHeight();
  let lastW = innerWidth;
  addEventListener("resize", () => {
    // only a real window resize (outer size or width) re-fits; the footer coming or going does not
    const widthChanged = innerWidth !== lastW; lastW = innerWidth;
    if (widthChanged) lockedFor = "";
    if (lockHeight() && typeof drawMori === "function") drawMori();
  });

  // ---------- background ----------
  function showBackground(step) {
    const list = C.backgrounds;
    if (!list.length) return;
    let i = local.get("bgIndex", -1);
    i = ((i + step) % list.length + list.length) % list.length;
    local.set("bgIndex", i);
    const b = list[i], el = $("bg"), img = new Image();
    el.classList.remove("ready");
    img.onload = () => {
      el.style.backgroundImage = `url("${b.file}")`;
      el.style.backgroundPosition = b.position || "center";
      requestAnimationFrame(() => el.classList.add("ready"));
    };
    img.src = b.file;
  }
  $("nextBg").hidden = C.backgrounds.length < 2;
  $("nextBg").addEventListener("click", () => showBackground(1));

  // ---------- retro pan ----------
  // Same pan + slow zoom as a smooth Ken Burns move, but sampled only R.fps times a second,
  // snapped to whole pixels, with a little random gate weave and flicker on every step.
  const R = Object.assign({ fps: 6, panSeconds: 16, weavePx: 1.5, flicker: 0.06 }, C.retro || {});
  const STEP = 1000 / R.fps;
  const rand = (n, salt) => { const x = Math.sin(n * 12.9898 + salt * 78.233) * 43758.5453; return x - Math.floor(x); };
  let lastStep = -1;
  function renderPan(ms) {
    const n = Math.floor(ms / STEP);
    if (n === lastStep) return; lastStep = n;
    const t = (n * STEP / 1000) / R.panSeconds;          // pan progress in "one-way passes"
    const p = t % 2 < 1 ? t % 2 : 2 - (t % 2);          // ping-pong 0..1..0
    const el = $("bg"), w = el.offsetWidth, h = el.offsetHeight;
    const x = Math.round(w * (-0.03 + 0.06 * p) + (rand(n, 1) - 0.5) * 2 * R.weavePx);
    const y = Math.round(h * (-0.01 + 0.02 * p) + (rand(n, 2) - 0.5) * 2 * R.weavePx * 0.7);
    const s = (1 + 0.05 * p).toFixed(3);
    el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${s})`;
    el.style.filter = `url(#ca) brightness(${(1 + (rand(n, 3) - 0.5) * 2 * R.flicker).toFixed(3)})`;
  }
  window.__mementoPan = renderPan;                        // lets a recorder step through frames
  const startPan = performance.now();
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    renderPan(0);
    setInterval(() => { if (!document.hidden) renderPan(performance.now() - startPan); }, STEP / 4);
  }

  // ---------- clocks ----------
  const use24 = !!C.clock24h;                            // fixed format (set in config.js)
  const hereZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  const cityFromZone = (z) => z.split("/").pop().replace(/_/g, " ");
  const ymd = (date, zone) => new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
  const hour23 = (date, zone) => Number(new Intl.DateTimeFormat("en-GB", { timeZone: zone, hour: "2-digit", hourCycle: "h23" }).format(date));

  const timeParts = (date, zone) => {
    const p = new Intl.DateTimeFormat("en-US", { timeZone: zone, hour: "numeric", minute: "2-digit", hour12: !use24, hourCycle: use24 ? "h23" : "h12" }).formatToParts(date);
    const get = (t) => (p.find(x => x.type === t) || {}).value || "";
    return { h: use24 ? get("hour").padStart(2, "0") : get("hour"), m: get("minute"), ap: use24 ? "" : get("dayPeriod") };
  };
  const digits = (s) => [...s].map(ch => `<span class="d">${ch}</span>`).join("");
  const slotTime = ({ h, m, ap }) =>
    `<span class="hh">${digits(h)}</span><span class="colon">:</span><span class="mm">${digits(m)}</span><span class="ap">${ap}</span>`;

  // Optical centring: digits sit in equal slots, so a narrow "1" leaves empty space on its left.
  // Shift the clock by half the difference between the hour digit's left gap and a minute digit's right gap.
  // Recomputed only when the hour changes, so the clock never moves minute to minute.
  const inkCanvas = document.createElement("canvas").getContext("2d");
  let centredFor = "";
  function centreClock(h) {
    const face = $("time"), first = face.querySelector(".d");
    if (!first) return;
    const cs = getComputedStyle($("clock"));
    inkCanvas.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
    const slot = first.getBoundingClientRect().width;
    const ink = (ch) => inkCanvas.measureText(ch);
    const a = ink(h[0]), z = ink("0");
    const gapLeft = (slot - a.width) / 2 - a.actualBoundingBoxLeft;     // empty space before the first digit's ink
    const gapRight = (slot + z.width) / 2 - z.actualBoundingBoxRight;   // empty space after a typical last digit's ink
    face.style.transform = `translateX(${(-(gapLeft - gapRight) / 2).toFixed(1)}px)`;
  }

  function renderClock(now) {
    const tp = timeParts(now);
    $("time").innerHTML = slotTime(tp);
    const key = tp.h + "|" + innerWidth + "|" + innerHeight;
    if (key !== centredFor && document.fonts.status === "loaded") { centredFor = key; centreClock(tp.h); }
    $("clock").setAttribute("aria-label", `${tp.h}:${tp.m} ${tp.ap}`);
    $("clock").classList.toggle("h24", use24);
    const h = now.getHours();
    const part = h < 5 ? "Up late" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
    $("greeting").textContent = C.name ? `${part}, ${C.name}.` : `${part}.`;
    $("date").textContent = now.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
    document.title = "New tab";
  }

  function renderZones(now) {
    const hereDate = ymd(now, hereZone);
    const sameAsHere = (z) => {
      // Two zone names can be the same place; compare offsets + names to merge "Here" into a city.
      if (z === hereZone) return true;
      return fmtFull(now, z) === fmtFull(now, hereZone) && cityFromZone(z) === cityFromZone(hereZone);
    };
    const cities = C.cities.map(c => ({ ...c, here: sameAsHere(c.zone) }));
    const list = cities.some(c => c.here) ? cities : [{ label: cityFromZone(hereZone), zone: hereZone, here: true }, ...cities];
    $("zones").replaceChildren(...list.map(c => {
      const li = document.createElement("li");
      if (c.here) { li.className = "here"; li.title = "Your current time zone"; }
      const h = hour23(now, c.zone), day = h >= 6 && h < 18;
      const diff = Math.round((Date.parse(ymd(now, c.zone)) - Date.parse(hereDate)) / DAY);
      li.innerHTML = `<span class="zone-name"><i class="sun ${day ? "day" : ""}" aria-label="${day ? "daytime" : "night"}"></i></span><span class="zone-time"></span>`;
      li.querySelector(".zone-name").append(c.label);
      if (c.here) { const sr = document.createElement("span"); sr.className = "sr"; sr.textContent = " (your time zone)"; li.querySelector(".zone-name").append(sr); }
      const t = li.querySelector(".zone-time");
      t.innerHTML = slotTime(timeParts(now, c.zone));
      if (diff) { const s = document.createElement("sup"); s.textContent = diff > 0 ? `+${diff}` : `−${-diff}`; s.title = diff > 0 ? "tomorrow" : "yesterday"; t.append(s); }
      return li;
    }));
  }
  const fmtFull = (d, z) => new Intl.DateTimeFormat("en-GB", { timeZone: z, dateStyle: "short", timeStyle: "short" }).format(d);


  // ---------- memento mori ----------
  const [by, bm, bd] = C.birthday.split("-").map(Number);
  const birthUTC = Date.UTC(by, bm - 1, bd);
  const TOTAL = C.lifeYears * 52;
  const ROWS = C.lifeYears, COLS = 52;
  let geo = null;

  function weeksLived(now) {
    const todayUTC = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
    const days = Math.round((todayUTC - birthUTC) / DAY);
    return { days, weeks: Math.min(TOTAL, Math.max(0, Math.floor(days / 7))) };
  }

  function drawMori() {
    const wrap = $("moriWrap"), cv = $("mori"), sec = wrap.parentElement;
    const dpr = window.devicePixelRatio || 1;
    // the grid fills the column's full height (less title and caption); width is capped so it never reaches the clock
    const SCALE = 0.86;                                   // grid size relative to the full column (slightly smaller than full)
    const availH = (sec.clientHeight - $("moriTitle").offsetHeight - sec.querySelector(".mori-caption").offsetHeight - 24) * SCALE;
    const W = Math.floor(innerWidth * 0.26 * SCALE * dpr), H = Math.floor(Math.max(availH, 120) * dpr);
    const decades = Math.floor((ROWS - 1) / 10);
    // PY = row pitch, stretched (fractionally) so the grid fills the full height; P = column pitch (whole pixels)
    const PY = Math.max(2, H / (ROWS + decades * 0.8));
    let P = Math.floor(Math.min(W / COLS, PY));
    P = Math.max(P, 2);
    const D = PY * 0.8;
    const gap = P >= 5 ? Math.max(2, Math.round(P * 0.38)) : 1;          // at least 2 device pixels between squares
    const cell = P - gap;
    const dot = Math.max(1, Math.round(P * 0.26));
    const gw = COLS * P - gap, gh = Math.round((ROWS - 1) * PY + decades * D) + cell;
    cv.width = gw; cv.height = gh;
    cv.style.width = gw / dpr + "px"; cv.style.height = gh / dpr + "px";
    const rowY = (r) => Math.round(r * PY + Math.floor(r / 10) * D);
    geo = { P, PY, D, cell, dpr, rowY };

    const { weeks } = weeksLived(new Date());
    const ctx = cv.getContext("2d");
    ctx.clearRect(0, 0, gw, gh);
    for (let i = 0; i < TOTAL; i++) {
      const r = Math.floor(i / COLS), c = i % COLS, x = c * P, y = rowY(r);
      if (i < weeks) { ctx.fillStyle = "rgba(237,232,218,0.82)"; ctx.fillRect(x, y, cell, cell); }
      else if (i > weeks) { ctx.fillStyle = "rgba(237,232,218,0.36)"; const o = Math.floor((cell - dot) / 2); ctx.fillRect(x + o, y + o, dot, dot); }
    }
    // current week marker
    const now = $("moriNow");
    if (weeks < TOTAL) {
      const r = Math.floor(weeks / COLS), c = weeks % COLS;
      const pad = Math.max(1, gap) / dpr;
      Object.assign(now.style, { display: "block", left: c * P / dpr - pad + "px", top: rowY(r) / dpr - pad + "px", width: cell / dpr + 2 * pad + "px", height: cell / dpr + 2 * pad + "px" });
    } else now.style.display = "none";

    const left = TOTAL - weeks;
    const { days } = weeksLived(new Date());
    $("moriLived").textContent = weeks.toLocaleString("en-US");
    $("moriLeft").textContent = `${left.toLocaleString("en-US")} left until ${C.lifeYears}, age ${(days / 365.2425).toFixed(1)}`;
    cv.setAttribute("aria-label", `Life in weeks: ${weeks.toLocaleString("en-US")} of ${TOTAL.toLocaleString("en-US")} weeks lived`);
  }

  const fmtDay = (ms) => new Date(ms).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
  $("mori").addEventListener("mousemove", (e) => {
    if (!geo) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) * geo.dpr, y = (e.clientY - rect.top) * geo.dpr;
    const c = Math.floor(x / geo.P);
    let r = -1;
    for (let k = 0; k < ROWS; k++) { const ry = geo.rowY(k); if (y >= ry && y < ry + geo.PY) { r = k; break; } }
    const tip = $("tip");
    if (r < 0 || c < 0 || c >= COLS) { tip.hidden = true; return; }
    const i = r * COLS + c, start = birthUTC + i * 7 * DAY;
    const { weeks } = weeksLived(new Date());
    const when = i < weeks ? "lived" : i === weeks ? "this week" : "ahead";
    tip.innerHTML = `<b>Week ${(i + 1).toLocaleString("en-US")}</b>, ${when}<br>${fmtDay(start)} to ${fmtDay(start + 6 * DAY)}<br>Age ${Math.floor(i / 52.1775)}`;
    tip.hidden = false;
    const tx = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8);
    const ty = Math.min(e.clientY + 14, innerHeight - tip.offsetHeight - 8);
    tip.style.left = tx + "px"; tip.style.top = ty + "px";
  });
  $("mori").addEventListener("mouseleave", () => { $("tip").hidden = true; });
  new ResizeObserver(() => drawMori()).observe(document.querySelector(".mori"));

  // ---------- to-do ----------
  let todos = [];
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // A finished item disappears at the midnight after it was ticked.
  const clearTime = (doneAt) => { const d = new Date(doneAt); d.setHours(24, 0, 0, 0); return d.getTime(); };
  function pruneDone() {
    const now = Date.now(), before = todos.length;
    todos = todos.filter(t => !(t.done && t.doneAt && now >= clearTime(t.doneAt)));
    return todos.length !== before;
  }
  const save = () => syncStore.set("todos", todos);

  function renderTodos() {
    const ul = $("todoList");
    ul.replaceChildren(...todos.map(t => {
      const li = document.createElement("li");
      li.draggable = true; li.dataset.id = t.id;
      if (t.done) li.classList.add("done");
      const check = document.createElement("button");
      check.type = "button"; check.className = "todo-check";
      check.setAttribute("role", "checkbox"); check.setAttribute("aria-checked", String(!!t.done));
      check.setAttribute("aria-label", t.done ? "Mark as not done" : "Mark as done");
      check.addEventListener("click", () => toggle(t.id));
      const text = document.createElement("span"); text.className = "todo-text"; text.textContent = t.text;
      const del = document.createElement("button");
      del.type = "button"; del.className = "todo-del"; del.textContent = "×"; del.setAttribute("aria-label", `Delete ${t.text}`);
      del.addEventListener("click", () => { todos = todos.filter(x => x.id !== t.id); save(); renderTodos(); });
      text.addEventListener("click", () => toggle(t.id));           // clicking the words ticks it too
      li.append(check, text, del);
      return li;
    }));
    $("todoEmpty").hidden = todos.length > 0;
  }

  function toggle(id) {
    const t = todos.find(x => x.id === id); if (!t) return;
    t.done = !t.done; t.doneAt = t.done ? Date.now() : null;
    todos = todos.filter(x => x !== t);
    if (t.done) todos.push(t);                                    // finished items sink to the bottom
    else { const firstDone = todos.findIndex(x => x.done); todos.splice(firstDone < 0 ? todos.length : firstDone, 0, t); }
    save(); renderTodos();
  }

  $("todoForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const input = $("todoInput"), text = input.value.trim();
    if (!text) return;
    const firstDone = todos.findIndex(x => x.done);
    todos.splice(firstDone < 0 ? todos.length : firstDone, 0, { id: uid(), text, done: false, doneAt: null });
    input.value = ""; save(); renderTodos();
    const ul = $("todoList"); ul.scrollTop = ul.scrollHeight;
  });

  // drag to reorder
  let dragId = null;
  const ul = $("todoList");
  ul.addEventListener("dragstart", (e) => { const li = e.target.closest("li"); if (!li) return; dragId = li.dataset.id; li.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
  ul.addEventListener("dragend", () => { dragId = null; ul.querySelectorAll("li").forEach(l => l.classList.remove("dragging", "drop-above")); });
  ul.addEventListener("dragover", (e) => {
    if (!dragId) return; e.preventDefault();
    ul.querySelectorAll("li").forEach(l => l.classList.remove("drop-above"));
    const li = e.target.closest("li"); if (li && li.dataset.id !== dragId) li.classList.add("drop-above");
  });
  ul.addEventListener("drop", (e) => {
    e.preventDefault(); if (!dragId) return;
    const target = e.target.closest("li");
    const moving = todos.find(t => t.id === dragId);
    todos = todos.filter(t => t.id !== dragId);
    const idx = target ? todos.findIndex(t => t.id === target.dataset.id) : todos.length;
    todos.splice(idx < 0 ? todos.length : idx, 0, moving);
    save(); renderTodos();
  });

  if (hasChrome) chrome.storage.onChanged.addListener((changes) => {
    if (changes.todos && Array.isArray(changes.todos.newValue)) { todos = changes.todos.newValue; renderTodos(); }
  });

  // ---------- quote ----------
  const quotes = (window.MEMENTO_QUOTES || []).filter(x => x.q.length <= C.maxQuoteLength);
  let current = null;
  function showQuote() {
    if (!quotes.length) return;
    const recent = local.get("recentQuotes", []);
    let pool = quotes.map((_, i) => i).filter(i => !recent.includes(i));
    if (!pool.length) pool = quotes.map((_, i) => i);
    const i = pool[Math.floor(Math.random() * pool.length)];
    local.set("recentQuotes", [i, ...recent].slice(0, Math.min(5, quotes.length - 1)));
    current = quotes[i];
    $("quoteText").textContent = current.q;
    $("quoteCredit").textContent = current.c;
  }
  $("nextQuote").addEventListener("click", showQuote);

  // ---------- Notion ----------
  const notion = $("notion");
  notion.href = C.notionUrl;
  $("pinterest").href = C.pinterestUrl;
  document.addEventListener("keydown", (e) => {
    const typing = e.target.closest("input, textarea, [contenteditable]");
    if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === "n" || e.key === "N") window.open(C.notionUrl, "_blank", "noopener");      // new tab
    if (e.key === "p" || e.key === "P") window.open(C.pinterestUrl, "_blank", "noopener");
  });

  // ---------- ticking ----------
  let lastDay = null;
  function tick() {
    const now = new Date();
    renderClock(now);
    renderZones(now);
    const day = now.toDateString();
    if (day !== lastDay) { lastDay = day; drawMori(); }
    if (pruneDone()) { save(); renderTodos(); }
  }
  function scheduleTicks() {
    tick();
    const msToMinute = 60000 - (Date.now() % 60000) + 20;
    setTimeout(() => { tick(); setInterval(tick, 60000); }, msToMinute);
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) tick(); });
  window.__mementoTick = tick;                           // used by the layout test

  // ---------- reveal ----------
  // The page stays invisible until the fonts are in and everything has its final size,
  // so the first frame you see never shifts.
  let revealed = false;
  function reveal() {
    if (revealed) return; revealed = true;
    centredFor = ""; renderClock(new Date());
    drawMori();
    requestAnimationFrame(() => document.documentElement.classList.add("ready"));
  }
  document.fonts.ready.then(reveal);
  setTimeout(reveal, 1000);                               // never stay hidden if a font fails

  // ---------- boot ----------
  showBackground(1);
  showQuote();
  scheduleTicks();
  syncStore.get("todos").then(v => { todos = Array.isArray(v) ? v : []; if (pruneDone()) save(); renderTodos(); });
})();
