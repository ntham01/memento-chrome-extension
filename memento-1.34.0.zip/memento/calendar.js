// Upcoming meetings, read from your calendar's private iCal link (Google Calendar → Settings →
// your calendar → "Secret address in iCal format"). Notion Calendar shows these same calendars.
(() => {
  "use strict";
  const C = window.MEMENTO_CONFIG;
  const $ = (id) => document.getElementById(id);
  const MIN = 6e4, HOUR = 36e5, DAY = 864e5;
  const toast = (m) => (window.mementoToast || console.log)(m);
  const store = chrome && chrome.storage && chrome.storage.local;
  const get = async (k) => store ? (await store.get(k))[k] : null;
  const set = async (k, v) => store && store.set({ [k]: v });

  // ---------- time zone helpers ----------
  const offsetCache = new Map();
  function tzOffset(ms, tz) {                       // ms offset of `tz` from UTC at instant `ms`
    const key = tz + Math.floor(ms / HOUR);
    if (offsetCache.has(key)) return offsetCache.get(key);
    let off = 0;
    try {
      const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(new Date(ms));
      const v = (t) => Number(p.find(x => x.type === t).value);
      off = Date.UTC(v("year"), v("month") - 1, v("day"), v("hour"), v("minute"), v("second")) - Math.floor(ms / 1000) * 1000;
    } catch { off = 0; }
    offsetCache.set(key, off);
    return off;
  }
  // wall-clock time in `tz` (or floating = local) → UTC ms
  function wallToUtc(w, tz) {
    const guess = Date.UTC(w.y, w.m - 1, w.d, w.h, w.mi, w.s);
    if (tz === "UTC") return guess;
    if (!tz) return new Date(w.y, w.m - 1, w.d, w.h, w.mi, w.s).getTime();
    let utc = guess - tzOffset(guess, tz);
    utc = guess - tzOffset(utc, tz);
    return utc;
  }

  // ---------- iCal parsing ----------
  function parseDate(value, params) {
    const m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})(Z)?)?$/.exec(value.trim());
    if (!m) return null;
    const w = { y: +m[1], m: +m[2], d: +m[3], h: +(m[4] || 0), mi: +(m[5] || 0), s: +(m[6] || 0) };
    const allDay = !m[4] || params.VALUE === "DATE";
    const tz = m[7] ? "UTC" : (params.TZID || (allDay ? null : null));
    return { w, tz, allDay };
  }
  const unescape = (s) => s.replace(/\\n/gi, "\n").replace(/\\([,;\\])/g, "$1");

  function parseICS(text) {
    const lines = text.replace(/\r\n[ \t]/g, "").replace(/\n[ \t]/g, "").split(/\r?\n/);
    const events = []; let cur = null;
    for (const line of lines) {
      if (line === "BEGIN:VEVENT") { cur = { exdates: [] }; continue; }
      if (line === "END:VEVENT") { if (cur) events.push(cur); cur = null; continue; }
      if (!cur) continue;
      const i = line.indexOf(":"); if (i < 0) continue;
      const [name, ...rawParams] = line.slice(0, i).split(";");
      const params = Object.fromEntries(rawParams.map(p => { const [k, v = ""] = p.split("="); return [k.toUpperCase(), v.replace(/^"|"$/g, "")]; }));
      const value = line.slice(i + 1);
      switch (name.toUpperCase()) {
        case "UID": cur.uid = value; break;
        case "SUMMARY": cur.title = unescape(value); break;
        case "LOCATION": cur.location = unescape(value); break;
        case "DESCRIPTION": cur.description = unescape(value); break;
        case "STATUS": cur.status = value.toUpperCase(); break;
        case "DTSTART": cur.start = parseDate(value, params); break;
        case "DTEND": cur.end = parseDate(value, params); break;
        case "DURATION": cur.duration = value; break;
        case "RRULE": cur.rrule = Object.fromEntries(value.split(";").map(p => p.split("="))); break;
        case "EXDATE": value.split(",").forEach(v => { const d = parseDate(v, params); if (d) cur.exdates.push(d); }); break;
        case "RECURRENCE-ID": cur.recurrenceId = parseDate(value, params); break;
        case "X-GOOGLE-CONFERENCE": cur.conference = value; break;
        case "URL": cur.url = value; break;
      }
    }
    return events;
  }

  function durationMs(s) {
    const m = /^([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(s || "");
    if (!m) return 0;
    return (m[1] === "-" ? -1 : 1) * ((+m[2] || 0) * 7 * DAY + (+m[3] || 0) * DAY + (+m[4] || 0) * HOUR + (+m[5] || 0) * MIN + (+m[6] || 0) * 1000);
  }

  const DOW = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
  const dayNum = (y, m, d) => Math.round(Date.UTC(y, m - 1, d) / DAY);          // days since epoch for a calendar date
  const fromDayNum = (n) => { const t = new Date(n * DAY); return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), dow: t.getUTCDay() }; };

  // Expand one event into concrete [start,end] instances that overlap [from, to].
  function instances(ev, from, to) {
    if (!ev.start) return [];
    const tz = ev.start.tz, base = ev.start.w;
    const startUtc = wallToUtc(base, tz);
    const len = ev.end ? wallToUtc(ev.end.w, ev.end.tz) - startUtc : ev.duration ? durationMs(ev.duration) : (ev.start.allDay ? DAY : 0);
    const out = [];
    const push = (s) => { if (s < to && s + len > from) out.push({ start: s, end: s + len }); };
    if (!ev.rrule) { push(startUtc); return out; }

    const r = ev.rrule, freq = (r.FREQ || "").toUpperCase(), interval = Math.max(1, +r.INTERVAL || 1);
    const count = r.COUNT ? +r.COUNT : Infinity;
    const until = r.UNTIL ? (() => { const u = parseDate(r.UNTIL, {}); return u ? wallToUtc(u.w, u.tz || tz) : Infinity; })() : Infinity;
    const ex = new Set(ev.exdates.map(x => wallToUtc(x.w, x.tz || tz)));
    const byday = (r.BYDAY || "").split(",").filter(Boolean).map(s => { const m = /^([+-]?\d+)?([A-Z]{2})$/.exec(s); return m ? { n: m[1] ? +m[1] : 0, dow: DOW.indexOf(m[2]) } : null; }).filter(Boolean);
    const bymonthday = (r.BYMONTHDAY || "").split(",").filter(Boolean).map(Number);
    const startDay = dayNum(base.y, base.m, base.d);
    const startDow = fromDayNum(startDay).dow;
    const weekStart = (n) => n - ((fromDayNum(n).dow + 6) % 7);                // Monday of that week
    const lastDay = Math.min(dayNum(new Date(to).getUTCFullYear(), new Date(to).getUTCMonth() + 1, new Date(to).getUTCDate()) + 1, startDay + 365 * 30);

    let n = 0;
    for (let day = startDay; day <= lastDay && n < count; day++) {
      const c = fromDayNum(day);
      let hit = false;
      if (freq === "DAILY") hit = (day - startDay) % interval === 0;
      else if (freq === "WEEKLY") {
        const weeks = Math.round((weekStart(day) - weekStart(startDay)) / 7);
        const days = byday.length ? byday.map(b => b.dow) : [startDow];
        hit = weeks % interval === 0 && days.includes(c.dow);
      } else if (freq === "MONTHLY") {
        const months = (c.y - base.y) * 12 + (c.m - base.m);
        if (months % interval === 0) {
          if (byday.length) {
            const dim = new Date(Date.UTC(c.y, c.m, 0)).getUTCDate();
            hit = byday.some(b => b.dow === c.dow && (b.n === 0 || (b.n > 0 && Math.ceil(c.d / 7) === b.n) || (b.n < 0 && Math.ceil((dim - c.d + 1) / 7) === -b.n)));
          } else hit = (bymonthday.length ? bymonthday : [base.d]).includes(c.d);
        }
      } else if (freq === "YEARLY") hit = (c.y - base.y) % interval === 0 && c.m === base.m && c.d === base.d;
      if (!hit) continue;
      const s = wallToUtc({ ...base, y: c.y, m: c.m, d: c.d }, tz);
      if (s > until) break;
      n++;
      if (!ex.has(s)) push(s);
    }
    return out;
  }

  const LINK_RE = /https:\/\/(?:meet\.google\.com\/[a-z\-]+|[\w.-]*zoom\.us\/j\/[^\s"<>]+|teams\.microsoft\.com\/l\/meetup-join\/[^\s"<>]+|calendar\.notion\.(?:so|com)\/meet\/[^\s"<>]+|[\w.-]*whereby\.com\/[^\s"<>]+)/i;
  const findLink = (ev) => { for (const f of [ev.conference, ev.location, ev.description, ev.url]) { const m = f && LINK_RE.exec(f); if (m) return m[0]; } return ""; };

  function upcoming(events, from, to) {
    const overrides = new Map();                     // uid -> set of overridden instance starts
    for (const ev of events) if (ev.recurrenceId) {
      const set = overrides.get(ev.uid) || new Set();
      set.add(wallToUtc(ev.recurrenceId.w, ev.recurrenceId.tz || (ev.start && ev.start.tz)));
      overrides.set(ev.uid, set);
    }
    const list = [];
    for (const ev of events) {
      if (ev.status === "CANCELLED" || !ev.start || ev.start.allDay) continue;   // meetings only; all-day items skipped
      const skip = !ev.recurrenceId && overrides.get(ev.uid);
      for (const inst of instances(ev, from, to)) {
        if (skip && skip.has(inst.start)) continue;
        list.push({ title: ev.title || "Busy", start: inst.start, end: inst.end, link: findLink(ev) });
      }
    }
    list.sort((a, b) => a.start - b.start);
    const seen = new Set();                          // the same meeting on two calendars shows once
    return list.filter(e => { const k = e.title + e.start; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  // ---------- fetching + caching ----------
  async function fetchAll(urls) {
    const all = [];
    for (const raw of urls) {
      const url = raw.trim().replace(/^webcal:\/\//i, "https://");
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error(`Calendar link returned ${res.status}`);
      const text = await res.text();
      if (!text.includes("BEGIN:VCALENDAR")) throw new Error("That link isn't an iCal calendar");
      all.push(...parseICS(text));
    }
    const now = Date.now();
    return upcoming(all, now - HOUR, now + 3 * DAY).slice(0, 60);   // three days ahead, so the cache stays good between refreshes
  }

  // ---------- rendering ----------
  const ROWS = 3;
  let cache = null, urls = [];
  const fmtTime = (ms) => new Date(ms).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  function when(e, now) {
    if (e.start <= now && e.end > now) return "Now";
    const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
    const day = Math.floor((e.start - d0.getTime()) / DAY);
    return (day === 0 ? "" : day === 1 ? "Tmrw " : new Date(e.start).toLocaleDateString("en-GB", { weekday: "short" }) + " ") + fmtTime(e.start);
  }
  function render() {
    const list = $("agendaList"), note = $("agendaNote");
    const now = Date.now();
    const evs = cache ? cache.events.filter(e => e.end > now && e.start < now + 2 * DAY).slice(0, ROWS) : [];
    list.replaceChildren(...evs.map(e => {
      const li = document.createElement("li");
      const a = document.createElement("a");
      a.href = e.link || C.notionCalendarUrl;
      a.target = "_blank"; a.rel = "noopener";
      a.title = e.link ? "Join" : "Open in Notion Calendar";
      if (e.start <= now && e.end > now) li.className = "live";
      const t = document.createElement("span"); t.className = "agenda-when"; t.textContent = when(e, now);
      const n = document.createElement("span"); n.className = "agenda-what"; n.textContent = e.title;
      a.append(t, n); li.append(a); return li;
    }));
    note.textContent = !urls.length ? "" : cache && cache.error ? cache.error : !cache ? "Loading…" : evs.length ? "" : "Nothing in the next two days.";
    $("calConnect").hidden = urls.length > 0;
  }

  async function refresh(force) {
    if (!urls.length) { cache = null; render(); return; }
    if (!force && cache && !cache.error && Date.now() - cache.fetchedAt < 10 * MIN) return;
    try {
      const events = await fetchAll(urls);
      cache = { events, fetchedAt: Date.now() };
    } catch (err) {
      cache = { events: cache ? cache.events : [], fetchedAt: Date.now(), error: "Couldn't load your calendar. Check the link in settings." };
      console.warn("Memento calendar:", err);
    }
    await set("calCache", cache);
    render();
  }

  // ---------- settings ----------
  function openForm() {
    $("calInput").value = urls.join("\n");
    $("calForm").hidden = false; $("agendaList").hidden = true; $("agendaNote").hidden = true; $("calConnect").hidden = true;
    document.querySelector(".agenda").classList.add("editing");          // hides the two links while the form is open
    $("calInput").focus();
  }
  function closeForm() {
    $("calForm").hidden = true; $("agendaList").hidden = false; $("agendaNote").hidden = false;
    document.querySelector(".agenda").classList.remove("editing"); render();
  }
  $("calSettings").addEventListener("click", () => $("calForm").hidden ? openForm() : closeForm());
  $("calConnect").addEventListener("click", openForm);
  $("calCancel").addEventListener("click", closeForm);
  $("calForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    urls = $("calInput").value.split(/\s+/).filter(u => /^(https|webcal):\/\//i.test(u));
    await set("calUrls", urls);
    cache = null; closeForm(); refresh(true);
  });

  // ---------- meeting link + Notion Calendar ----------
  $("openCal").href = C.notionCalendarUrl;
  async function copyMeet() {
    try { await navigator.clipboard.writeText(C.meetLink); toast("Meeting link copied"); }
    catch { toast("Couldn’t copy the meeting link"); }
  }
  $("copyMeet").addEventListener("click", copyMeet);
  document.addEventListener("keydown", (e) => {
    if (e.target.closest("input, textarea, [contenteditable]") || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === "m" || e.key === "M") copyMeet();
  });

  // ---------- boot ----------
  (async () => {
    urls = (await get("calUrls")) || (C.calendarIcsUrls || []);
    cache = (await get("calCache")) || null;
    render();
    refresh(false);
    setInterval(() => { render(); refresh(false); }, MIN);
  })();
  window.__mementoCalendar = { parseICS, upcoming, refresh };     // used by tests
})();
