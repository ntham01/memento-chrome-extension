// Runs inside the Instagram embed shown in Memento's "Today's save" panel.
// Hides Instagram's header, caption, likes and footer, turns the background black,
// and lets the post's video (or image) fill the frame. Does nothing anywhere else.
(() => {
  "use strict";
  const parent = (location.ancestorOrigins && location.ancestorOrigins[0]) || "";
  if (window.top === window || parent !== `chrome-extension://${chrome.runtime.id}`) return;

  const style = document.createElement("style");
  style.textContent = `
    html.memento-ig, html.memento-ig body { background: #000 !important; margin: 0 !important; overflow: hidden !important; }
    html.memento-ig body * { visibility: hidden !important; }
    html.memento-ig .memento-media {
      visibility: visible !important; position: fixed !important; inset: 0 !important;
      width: 100% !important; height: 100% !important; max-width: none !important; max-height: none !important;
      object-fit: cover !important; transform: none !important; margin: 0 !important; z-index: 2147483646 !important;
      background: #000 !important; cursor: pointer !important;
    }
    html.memento-ig .memento-play, html.memento-ig .memento-play * { visibility: visible !important; }
    html.memento-ig .memento-play {
      visibility: visible !important; position: fixed; left: 50%; top: 50%; width: 56px; height: 56px; margin: -28px 0 0 -28px;
      z-index: 2147483647; pointer-events: none; opacity: 0.85; transition: opacity 150ms;
    }
    html.memento-ig .memento-play.hide { opacity: 0; }
  `;
  const root = document.documentElement;
  root.classList.add("memento-ig");
  (document.head || root).appendChild(style);

  const play = document.createElement("div");
  play.className = "memento-play";
  play.innerHTML = '<svg viewBox="0 0 56 56" width="56" height="56"><circle cx="28" cy="28" r="27" fill="rgba(0,0,0,.45)" stroke="rgba(237,232,218,.7)"/><path d="M23 18l15 10-15 10z" fill="#ede8da"/></svg>';

  let current = null;
  const area = (el) => { const r = el.getBoundingClientRect(); return (r.width || el.videoWidth || el.naturalWidth || 0) * (r.height || el.videoHeight || el.naturalHeight || 0); };
  function pick() {
    const videos = [...document.querySelectorAll("video")];
    const imgs = [...document.querySelectorAll("img")].filter(i => (i.naturalWidth || i.width) > 150);   // skip avatars and icons
    const el = (videos.length ? videos : imgs).sort((a, b) => area(b) - area(a))[0];
    if (!el || el === current) return;
    if (current) current.classList.remove("memento-media");
    current = el;
    el.classList.add("memento-media");
    if (el.tagName === "VIDEO") {
      el.controls = false; el.loop = true; el.playsInline = true;
      const sync = () => play.classList.toggle("hide", !el.paused);
      el.addEventListener("play", sync); el.addEventListener("pause", sync); sync();
      el.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); el.paused ? el.play() : el.pause(); }, true);
    } else {
      play.classList.toggle("hide", !document.querySelector('[aria-label*="Play" i], [class*="Play" i], [class*="Video" i]'));
    }
    if (!play.isConnected) document.body.appendChild(play);
  }
  new MutationObserver(pick).observe(root, { childList: true, subtree: true });
  document.addEventListener("DOMContentLoaded", pick);
  addEventListener("load", pick);
})();
