// Today's story: one short read a day on global history, shipping, supply chains, business and geopolitics.
// The stories live in stories.js. A new one appears each day; "Earlier" steps back through past days.
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const stories = window.MEMENTO_STORIES || [];
  const btn = $("storyBtn"), panel = $("storyPanel");
  if (!btn || !panel) return;
  if (!stories.length) { btn.hidden = true; return; }

  const dayNumber = (d) => Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5);
  const START = dayNumber(new Date(2026, 10, 14));          // the first story (Hamburg) went out on 14 November 2026
  const at = (day) => stories[(((day - START) % stories.length) + stories.length) % stories.length];

  const key = "memento:seenStory";
  const seenToday = () => { try { return localStorage.getItem(key) === String(dayNumber(new Date())); } catch { return false; } };
  const markSeen = () => { try { localStorage.setItem(key, String(dayNumber(new Date()))); } catch {} $("storyDot").hidden = true; };

  let back = 0;   // 0 = today, 1 = yesterday's story, ...
  const when = (n) => n === 0 ? "Today" : n === 1 ? "Yesterday" : `${n} days ago`;

  function fill() {
    const s = at(dayNumber(new Date()) - back);
    $("storyTag").textContent = s.t || "";
    $("storyDay").textContent = when(back);
    $("storyQ").textContent = s.q;
    $("storyM").textContent = s.m || "";
    $("storyTldr").replaceChildren(...(s.tl || []).map((x) => { const li = document.createElement("li"); li.textContent = x; return li; }));
    $("storyTldr").parentElement.hidden = !(s.tl && s.tl.length);
    const img = $("storyImg");
    if (s.img) { img.src = s.img; img.alt = s.ic || ""; img.parentElement.hidden = false; } else { img.removeAttribute("src"); img.parentElement.hidden = true; }
    $("storyCap").textContent = s.ic || "";
    $("storyBody").replaceChildren(...s.b.map((para) => { const p = document.createElement("p"); p.textContent = para; return p; }));
    $("storyBody").scrollTop = 0;
    $("storyMore").href = "https://en.wikipedia.org/w/index.php?search=" + encodeURIComponent(s.w || s.q);
    $("storyNext").disabled = back === 0;
    $("storyPrev").disabled = back >= stories.length - 1;
  }

  function open() { window.__mementoSaves && window.__mementoSaves.close(); back = 0; fill(); panel.hidden = false; btn.setAttribute("aria-expanded", "true"); markSeen(); }
  function close() { panel.hidden = true; btn.setAttribute("aria-expanded", "false"); }
  const toggle = () => (panel.hidden ? open() : close());

  $("storyPrev").addEventListener("click", () => { if (back < stories.length - 1) { back++; fill(); } });
  $("storyNext").addEventListener("click", () => { if (back > 0) { back--; fill(); } });
  btn.addEventListener("click", (e) => { e.stopPropagation(); toggle(); });
  document.addEventListener("click", (e) => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) close(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.hidden) { close(); btn.focus(); return; }
    if (e.target.closest("input, textarea, [contenteditable]") || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === "g" || e.key === "G") toggle();
    if (!panel.hidden && e.key === "ArrowLeft") $("storyPrev").click();
    if (!panel.hidden && e.key === "ArrowRight") $("storyNext").click();
  });

  $("storyDot").hidden = seenToday();
  window.__mementoStory = { open, close, at };
})();
