// One story a day under the globe icon: short reads on global history, shipping, supply chains, business and geopolitics.
// k = id, t = tag, q = the question, m = why it matters, tl = TL;DR bullets, img/ic = picture and its caption, b = paragraphs, w = Wikipedia search.
window.MEMENTO_STORIES = [
 {
  "k": "hamburg",
  "t": "Shipping",
  "q": "Why does Germany’s biggest port lose to a Dutch one?",
  "m": "Geography still beats money: a city can pour billions into its port and still lose to a rival that is simply closer to the sea.",
  "tl": [
   "Hamburg is 100+ km up a tidal, depth-limited river",
   "The biggest ships come in on the tide, often not fully loaded",
   "Its edge is rail: boxes go deep into Central and Eastern Europe"
  ],
  "img": "assets/stories/hamburg.webp",
  "ic": "The Elbe runs about 100 km from Hamburg to the North Sea; Rotterdam and Antwerp sit almost on the coast.",
  "b": [
   "Hamburg is Germany’s gateway to the world, yet it handles roughly 8 million containers a year to Rotterdam’s 13 million or more. The reason is geography. Hamburg sits more than 100 km up the Elbe, so every call adds hours of river sailing, pilots and tide-watching. The biggest ships can only come up at high water, often not fully loaded, and the low Köhlbrand Bridge (1974) blocks the largest vessels from one of its own terminals.",
   "Rotterdam and Antwerp-Bruges sit almost on the open sea, with deep water on reclaimed land, and Valencia gives Asian cargo a shortcut into the Mediterranean. For a liner company calling every week, a few hours and a few hundred dollars per container add up to millions, so port choice is strategy. Hamburg’s answer is its hinterland: it is Europe’s largest rail port, moving boxes deep into Central and Eastern Europe."
  ],
  "w": "Port of Hamburg"
 },
 {
  "k": "mclean",
  "t": "Supply chain",
  "q": "How did a truck driver end up shrinking the world?",
  "m": "The biggest leap in globalisation wasn’t a computer or a trade deal. It was a steel box, from a man who wasn’t even in shipping.",
  "tl": [
   "A trucker, Malcom McLean, put 58 trailers on a ship in 1956",
   "Loading cost fell from about $6 a ton to 16 cents",
   "Standard boxes made making things far away cheap"
  ],
  "img": "assets/stories/mclean.webp",
  "ic": "The Ideal-X’s first container voyage, April 1956.",
  "b": [
   "Malcom McLean was a trucking boss from North Carolina, not a sailor. Tired of watching trucks wait while dockworkers unloaded cargo sack by sack, he put 58 truck trailers on a converted wartime tanker, the Ideal-X, which sailed from Newark to Houston on 26 April 1956. Before then, ships spent nearly as long in port as at sea, and theft and damage were routine. McLean estimated loading costs fell from almost $6 a ton to about 16 cents.",
   "The box turned shipping from a craft into a system: cranes, trucks and trains all handling one standard unit. During the Vietnam War, McLean’s ships supplied US forces and, rather than sail home empty, stopped in Japan to pick up exports. That backhaul helped start the trans-Pacific trade that made it cheaper to build things in Asia than next door."
  ],
  "w": "Malcom McLean"
 },
 {
  "k": "ballin",
  "t": "History",
  "q": "Why did a shipping line build a town its guests couldn’t leave?",
  "m": "Treating poor emigrants well wasn’t charity. It was the cheapest way to avoid paying for their trip back.",
  "tl": [
   "US law made lines carry rejected passengers home for free",
   "Ballin built a health-checked emigrant city on Veddel in 1901",
   "Healthier passengers meant fewer returns and better word of mouth"
  ],
  "img": "assets/stories/ballin.webp",
  "ic": "Most emigrants reached Hamburg by train, then sailed for New York.",
  "b": [
   "Around 1900, millions of Eastern Europeans were heading for America, and many passed through Hamburg. They waited for ships in cramped lodgings around the port. After a cholera epidemic killed thousands of Hamburgers in 1892, the city grew suspicious of them, even though the real cause was the city’s unfiltered water. There was also a business problem: under an 1891 US law, a line had to carry any passenger rejected at Ellis Island back home at its own cost.",
   "HAPAG’s director, Albert Ballin, built the Emigrant Halls on the island of Veddel in 1901: dormitories, kitchens, baths, a church and a synagogue, and doctors who checked everyone before boarding. Emigrants stayed inside the fenced complex, kept apart from the city, until their ship sailed. Healthier passengers meant fewer expensive returns, and good treatment spread by word of mouth to the next village. Part of the site is now the BallinStadt emigration museum."
  ],
  "w": "BallinStadt"
 },
 {
  "k": "hormuz",
  "t": "Geopolitics",
  "q": "How can a strait 33 km wide set the price of your petrol?",
  "m": "World energy is supposedly global and diversified, yet a fifth of its oil squeezes through one gap you could drive across in half an hour.",
  "tl": [
   "The only sea exit from the Persian Gulf, about 33 km wide",
   "Around a fifth of the world’s oil passes through it",
   "Even a threat raises insurance and freight costs"
  ],
  "img": "assets/stories/hormuz.webp",
  "ic": "The tanker lanes through Hormuz, and the UAE’s bypass pipeline to Fujairah.",
  "b": [
   "The Strait of Hormuz, between Iran and Oman, is the only sea exit from the Persian Gulf. At its narrowest it is about 33 km wide, and the shipping lanes are just two miles each way. Around a fifth of the world’s oil consumption passes through it every day, along with much of Qatar’s liquefied natural gas. Saudi Arabia and the UAE have pipelines that bypass it, but they can carry only a fraction of the flow.",
   "Ships don’t need to be attacked for the strait to matter. When tensions rise, war-risk insurance premiums jump, some owners stay away and freight rates climb. During the Iran–Iraq ‘Tanker War’ of the 1980s, the US even reflagged Kuwaiti tankers as American ships so its navy could escort them."
  ],
  "w": "Strait of Hormuz"
 },
 {
  "k": "bananas",
  "t": "Supply chain",
  "q": "Why do bananas cross the ocean asleep at 13°C?",
  "m": "The world’s favourite fruit is almost all one clone, kept asleep for weeks, and a single fungus has wiped out its predecessor before.",
  "tl": [
   "Bananas travel green in reefers at around 13°C",
   "Ethylene gas in ripening rooms turns them yellow on schedule",
   "Almost all are one variety: the Cavendish"
  ],
  "img": "assets/stories/bananas.webp",
  "ic": "Reefers keep bananas cool from Latin America to Europe.",
  "b": [
   "Bananas are picked unripe and shipped in refrigerated containers (reefers) held at around 13°C. Much colder and the fruit suffers chilling injury and turns grey. Much warmer and it starts ripening, releasing ethylene gas that sets off every banana around it. Reefers also control humidity and fresh-air exchange, and some lower the oxygen to slow the fruit’s breathing even more. Reefers are white because white reflects the sun.",
   "When they arrive, the bananas go into ripening rooms, where a measured dose of ethylene turns them yellow over several days, timed to the supermarket’s orders. Bananas are among the most traded fruits in the world, and almost all of them are one variety, the Cavendish. It took over after a fungus wiped out the earlier Gros Michel in the 1950s."
  ],
  "w": "Refrigerated container"
 },
 {
  "k": "voc",
  "t": "Business",
  "q": "How did a spice company invent the stock market?",
  "m": "The company that invented modern shareholding was also a private army. The stock market was born armed.",
  "tl": [
   "Founded in 1602 with permanent capital and tradable shares",
   "Trading those shares created the Amsterdam stock exchange",
   "It could also wage war, make treaties and run colonies"
  ],
  "img": "assets/stories/voc.webp",
  "ic": "The VOC route: Amsterdam, the Cape, then east on the Roaring Forties to Batavia.",
  "b": [
   "Founded in 1602, the VOC (Vereenigde Oostindische Compagnie) let ordinary people buy shares, and, crucially, kept that capital permanently instead of returning it after each voyage. Investors who wanted out couldn’t ask for their money back, so they sold their shares to someone else. That trading became the Amsterdam stock exchange, arguably the world’s first.",
   "It was also far more than a company. The Dutch state let the VOC build forts, keep soldiers, make treaties and wage war across Asia. It dominated the spice trade, often brutally, and ran a vast network from the Cape to Batavia (Jakarta) and Japan. Corruption and debt finally sank it in 1799, but the idea of a permanent, tradable company outlived it."
  ],
  "w": "Dutch East India Company"
 },
 {
  "k": "empties",
  "t": "Trade",
  "q": "Why are ships crossing the Pacific full of nothing?",
  "m": "Globalisation looks like a two-way street but runs mostly one way, so shipping lines pay billions a year to move nothing.",
  "tl": [
   "Asia exports far more than it imports",
   "Roughly one in five container moves is an empty box",
   "Lines discount backhauls just to get boxes home"
  ],
  "img": "assets/stories/empties.webp",
  "ic": "Full boxes leave Asia; many come back empty.",
  "b": [
   "Trade is lopsided. Asia ships far more to Europe and North America than it buys back, so boxes pile up in Los Angeles and Rotterdam while factories in China need them. Lines have to send them back empty, and industry estimates often put roughly one in five container moves as an empty box. That repositioning costs billions a year and earns nothing.",
   "Reefers are even harder. China imports cherries and blueberries from Chile and Peru in refrigerated boxes, but little cold cargo goes the other way, so lines offer cheap rates to anyone who will fill one heading back. In 2021 the problem exploded: boxes were stuck in the wrong places and Asia–Europe rates rose roughly tenfold. Foldable containers exist, but cost and handling have kept them niche."
  ],
  "w": "Container repositioning"
 },
 {
  "k": "opium",
  "t": "History",
  "q": "How did Britain’s tea habit end with it taking Hong Kong?",
  "m": "Britain fought a war in the name of ‘free trade’ so it could keep selling a drug China had banned.",
  "tl": [
   "Britain bought Chinese tea and paid in silver",
   "It reversed the flow by smuggling Bengal opium into China",
   "The 1842 treaty opened ports and handed over Hong Kong"
  ],
  "img": "assets/stories/opium.webp",
  "ic": "Opium went from Bengal to China, and silver came back.",
  "b": [
   "In the 1700s Britain fell in love with Chinese tea, but China wanted little in return except silver, so silver drained steadily out of Britain. The East India Company found a fix: grow opium in Bengal and sell it at auction to private traders, who smuggled it into China. The silver flowed back.",
   "In 1839 the Chinese official Lin Zexu seized and destroyed more than 1,000 tonnes of opium at Humen. Britain answered with warships. The 1842 Treaty of Nanking forced China to pay compensation, open five ports to trade and hand over Hong Kong Island. In China the war marks the start of the ‘Century of Humiliation’, and that memory still shapes how Beijing views trade and the West."
  ],
  "w": "First Opium War"
 },
 {
  "k": "slow",
  "t": "Shipping",
  "q": "Why do today’s giant ships go slow on purpose?",
  "m": "Ships could go faster than they did 40 years ago. The cheapest and greenest choice is to go slower.",
  "tl": [
   "Fuel is a line’s biggest cost, and it rises steeply with speed",
   "Going from 24 to 18 knots saves roughly 40% of fuel",
   "Ships got bigger and cleaner instead of faster"
  ],
  "img": "assets/stories/slow.webp",
  "ic": "Fuel per voyage rises roughly with the square of speed.",
  "b": [
   "Fuel is a shipping line’s biggest running cost, and a ship’s fuel burn climbs steeply with speed, roughly with its cube. Cutting from 24 knots to 18 uses something like 40% less fuel over the same voyage. After oil prices spiked and trade collapsed in 2008, Maersk led a shift to ‘slow steaming’. Adding a ship to each route kept the weekly schedule, and it also soaked up a glut of new ships nobody needed.",
   "Emissions push the same way. Since 2020, global rules have capped sulphur in marine fuel, and lines are now ordering ships that can run on methanol or LNG. Maersk’s first methanol-powered container ship was named in 2023. So the industry got bigger and more efficient instead of faster: today’s giants carry far more boxes at speeds that would have looked lazy in the 1970s."
  ],
  "w": "Slow steaming"
 },
 {
  "k": "taiwan",
  "t": "Geopolitics",
  "q": "Why does the world’s tech run through one island?",
  "m": "The more the world depends on Taiwan’s chips, the safer Taiwan may be, and the costlier any mistake becomes.",
  "tl": [
   "TSMC makes chips for others and never competes with them",
   "It produces the vast majority of the most advanced chips",
   "That is either a ‘silicon shield’ or a single point of failure"
  ],
  "img": "assets/stories/taiwan.webp",
  "ic": "TSMC is based in Hsinchu, across the Taiwan Strait from mainland China.",
  "b": [
   "In 1987 Morris Chang founded TSMC in Taiwan around an unusual idea: make chips that other companies design and never compete with your customers. That ‘pure-play foundry’ model let Apple, Nvidia and AMD design chips without owning factories, while TSMC poured the profits into ever more advanced manufacturing. Today it makes the vast majority of the world’s most advanced processors.",
   "A leading-edge fab costs over $20 billion and takes years of know-how to run, so the advantage is hard to copy. Some in Taiwan call it a ‘silicon shield’: the world can’t afford a war that stops those fabs. Others see it as concentrated risk, which is why TSMC is now building plants in Arizona, Japan and Germany, though most of its best work remains at home."
  ],
  "w": "TSMC"
 },
 {
  "k": "imperator",
  "t": "History",
  "q": "How did the Kaiser’s pride and joy end up flying a British flag?",
  "m": "A ship built to show off Germany’s power ended up serving the rival it was meant to beat.",
  "tl": [
   "Ships are christened for luck; the Kaiser named Imperator in 1912",
   "It was the world’s largest ship, Ballin’s bid to beat the British",
   "After WWI it went to Britain as reparations"
  ],
  "img": "assets/stories/imperator.webp",
  "ic": "Imperator’s maiden voyage, 1913, and its later home port as Cunard’s Berengaria.",
  "b": [
   "Sailors have blessed new ships for thousands of years. Today a ‘sponsor’ or godmother names the ship and breaks a bottle on the bow, and an unchristened ship is considered bad luck. In 1912 Kaiser Wilhelm II christened HAPAG’s Imperator in Hamburg, then the largest ship in the world. It was Albert Ballin’s bid to beat Britain’s Cunard and White Star on size and luxury.",
   "Within a few years the bet was lost. After the First World War, Germany had to hand over its great liners as reparations. Imperator briefly carried American troops home, then went to Cunard as the Berengaria. Its sisters Vaterland and Bismarck became the Leviathan and the Majestic. HAPAG had to rebuild almost from nothing."
  ],
  "w": "SS Imperator"
 },
 {
  "k": "bullwhip",
  "t": "Supply chain",
  "q": "Why did nappies send Procter & Gamble’s orders haywire?",
  "m": "Every company in the chain acts sensibly on its own, and together they create chaos nobody wanted.",
  "tl": [
   "Steady consumer demand turns into wild swings upstream",
   "Each link sees orders, not real demand, and over-orders",
   "The fix is sharing real sales data along the chain"
  ],
  "img": "assets/stories/bullwhip.webp",
  "ic": "Each step up the chain over-reacts to the step below.",
  "b": [
   "In the early 1990s, Procter & Gamble noticed something odd about Pampers. Babies use nappies at a steady rate and store sales were smooth, yet distributors’ orders to P&G swung wildly, and P&G’s own orders to its suppliers swung even more. This amplification became known as the bullwhip effect.",
   "Each link in the chain sees only the orders from the link below it, not real demand. Orders get batched, promotions pull purchases forward, and when supplies run short people order extra to protect themselves. MIT’s ‘Beer Game’ has shown the effect in classrooms since the 1960s, and Covid-era toilet paper showed it in real life. The fixes are mostly about sharing information: point-of-sale data, vendor-managed inventory and steady pricing."
  ],
  "w": "Bullwhip effect"
 },
 {
  "k": "suez",
  "t": "Shipping",
  "q": "How did one ship stuck sideways jam world trade for six days?",
  "m": "The more efficient trade gets, the fewer routes it uses, and the more one stuck ship can stop.",
  "tl": [
   "Around 12% of world trade goes through the canal",
   "The Cape route adds about 3,500 nautical miles",
   "The Ever Given (2021) and Red Sea attacks showed how fragile it is"
  ],
  "img": "assets/stories/suez.webp",
  "ic": "Through Suez, or around the Cape of Good Hope.",
  "b": [
   "The Suez Canal, opened in 1869, links the Mediterranean and the Red Sea, and around 12% of world trade passes through it. The alternative for Asia–Europe trade is sailing around the Cape of Good Hope, which adds roughly 3,500 nautical miles and well over a week. In March 2021 the Ever Given ran aground across the canal for six days, and hundreds of ships queued at both ends.",
   "From late 2023, attacks on shipping near the Bab-el-Mandeb strait by Yemen’s Houthis led most container lines to avoid the Red Sea altogether. Going around Africa tied up so many extra ships that freight rates jumped, and Egypt lost billions in canal fees. A route is only as good as its narrowest point."
  ],
  "w": "Suez Canal"
 },
 {
  "k": "lloyds",
  "t": "Business",
  "q": "Why is a giant shipping line named after a London coffee house?",
  "m": "Global industries still run on old reputations: a name from a 17th-century coffee house still signals trust at sea.",
  "tl": [
   "Lloyd’s of London began in a 1680s coffee house",
   "‘Lloyd’ came to mean reliable shipping, so Bremen borrowed it",
   "HAPAG (Hamburg) and NDL (Bremen) merged in 1970"
  ],
  "img": "assets/stories/lloyds.webp",
  "ic": "Three cities, two lines, one famous name.",
  "b": [
   "In the 1680s Edward Lloyd ran a coffee house in London where captains, merchants and insurers gathered for shipping news. Insurers there wrote their names under the risk they agreed to cover, which is where the word ‘underwriter’ comes from. That gathering became Lloyd’s of London, and Lloyd’s List, started in 1734, is one of the oldest news sheets still published.",
   "The name came to stand for reliable shipping, so when Bremen merchants founded a line in 1857 they called it Norddeutscher Lloyd. Hamburg’s rival was the Hamburg-Amerikanische Packetfahrt-Actien-Gesellschaft, HAPAG for short, founded in 1847 to carry mail ‘packets’. The two old enemies merged in 1970 to form Hapag-Lloyd."
  ],
  "w": "Lloyd's Coffee House"
 },
 {
  "k": "flags",
  "t": "Shipping",
  "q": "Why are so many ships registered in Liberia, from an office in Virginia?",
  "m": "The flag on a ship’s stern often has almost nothing to do with who owns it, crews it or profits from it.",
  "tl": [
   "Ships can register in countries their owners never visit",
   "Panama, Liberia and the Marshall Islands are the biggest registries",
   "Low tax and light rules, but hard to hold anyone accountable"
  ],
  "img": "assets/stories/flags.webp",
  "ic": "The three biggest flags in shipping.",
  "b": [
   "A ship can fly the flag of a country its owner has never visited. Panama, Liberia and the Marshall Islands run the world’s largest registries by tonnage. The practice took off in the 1920s, when some American shipowners re-registered in Panama, partly to serve alcohol during Prohibition and partly to escape US crewing rules. Liberia’s registry was set up in 1948 with help from former US Secretary of State Edward Stettinius, and is run from offices in Virginia.",
   "Owners get lower taxes, cheaper crews and lighter paperwork. Critics say these ‘flags of convenience’ make it hard to hold anyone responsible when things go wrong, and the ‘shadow fleets’ carrying sanctioned oil often shop for the most obliging flag they can find."
  ],
  "w": "Flag of convenience"
 },
 {
  "k": "nutmeg",
  "t": "History",
  "q": "Did the Dutch really give up Manhattan for a nutmeg island?",
  "m": "What counts as the prize keeps changing. In 1667 a speck of land with nutmeg looked worth more than Manhattan.",
  "tl": [
   "Nutmeg grew only in the tiny Banda Islands",
   "The 1667 Treaty of Breda let each side keep what it held",
   "The Dutch kept Run; the English kept New York"
  ],
  "img": "assets/stories/nutmeg.webp",
  "ic": "Run in the Banda Islands, and New Amsterdam.",
  "b": [
   "In the 1600s nutmeg grew in only one place, the tiny Banda Islands in what is now Indonesia, and it sold in Europe for many times its cost. The Dutch East India Company conquered the islands violently in 1621, but the English held one speck called Run. Meanwhile, in 1664 the English seized the Dutch colony of New Amsterdam in North America.",
   "The 1667 Treaty of Breda let each side keep what it held: the Dutch kept Run, and the English kept New Amsterdam, by then renamed New York. It wasn’t quite a straight swap, but it is often told as one. At the time the Dutch probably thought they had the better deal."
  ],
  "w": "Treaty of Breda (1667)"
 },
 {
  "k": "kanban",
  "t": "Business",
  "q": "What did Toyota learn from an American supermarket?",
  "m": "The world’s most copied factory system came from watching shoppers, and even Toyota learned to keep some stock after all.",
  "tl": [
   "Toyota copied how supermarkets restock shelves",
   "Pull, don’t push: make only what was just used",
   "Toyota kept chip buffers after 2011 and beat the 2021 shortage"
  ],
  "img": "assets/stories/kanban.webp",
  "ic": "Kanban: each step makes only what the next step just used.",
  "b": [
   "Visiting the US in the 1950s, Toyota’s Taiichi Ohno was struck by how supermarkets restocked shelves only as customers took things off them. He built Toyota’s production system around the same idea: each process pulls parts from the one before it, signalled by kanban cards, so nothing is made before it is needed. Inventory hides problems, so with less of it, problems surface and get fixed.",
   "‘Just-in-time’ and ‘lean’ spread worldwide after the 1990 MIT study The Machine That Changed the World. But after the 2011 Tōhoku earthquake exposed how fragile thin stocks can be, Toyota mapped its suppliers and kept months of critical chips on hand. When the 2021 chip shortage hit, it kept building cars while rivals stopped."
  ],
  "w": "Toyota Production System"
 },
 {
  "k": "malacca",
  "t": "Geopolitics",
  "q": "Why is a 3 km channel China’s biggest weak spot?",
  "m": "China is the world’s biggest trading nation, yet much of its oil must sail past rival navies through one narrow lane.",
  "tl": [
   "Under 3 km wide at its narrowest, near Singapore",
   "Most of China’s imported oil passes through it",
   "Pipelines, ports and a bigger navy are China’s hedges"
  ],
  "img": "assets/stories/malacca.webp",
  "ic": "Most of China’s imported oil comes through this one strait.",
  "b": [
   "The Strait of Malacca runs between the Malay Peninsula and Sumatra, and at its narrowest, near Singapore, the channel is under 3 km wide. A huge share of world trade passes through it, including most of China’s imported oil. In 2003 China’s president Hu Jintao reportedly called this the ‘Malacca dilemma’: in a crisis, a rival navy could choke China’s energy supply at one spot.",
   "Much of China’s strategy since then makes more sense in that light: pipelines across Myanmar, a port at Gwadar in Pakistan, overland Belt and Road links, a bigger navy and strategic oil reserves. Each one is a way to depend a little less on a single narrow strait."
  ],
  "w": "Malacca dilemma"
 },
 {
  "k": "tshirt",
  "t": "Trade",
  "q": "Why does it cost about 10 cents to ship a T-shirt round the world?",
  "m": "Moving a shirt halfway round the planet costs less than a bus ticket, so distance barely decides where things are made.",
  "tl": [
   "One 20-foot box holds something like 20,000 T-shirts",
   "Freight works out to around 10 cents a shirt",
   "So distance barely matters; labour and skills do"
  ],
  "img": "assets/stories/tshirt.webp",
  "ic": "The maths of moving a T-shirt across the world.",
  "b": [
   "The biggest container ships now carry around 24,000 twenty-foot boxes. One twenty-foot box can hold something like 20,000 folded T-shirts. If moving that box from Asia to Europe costs a couple of thousand dollars in a normal year, the freight works out to about ten cents a shirt, often around 1% of what you pay in the shop.",
   "That is why production can move wherever labour, skills and supplier networks are cheapest: distance has become nearly free. Air freight is a different world, often dozens of times more expensive per kilo, and is kept for things that are light, valuable or urgent."
  ],
  "w": "Containerization"
 },
 {
  "k": "hansa",
  "t": "History",
  "q": "Why do Hamburg’s number plates start with HH?",
  "m": "Long before the EU, northern European cities built a trading union without a state, and Hamburg still wears the badge.",
  "tl": [
   "A medieval club of merchant towns, led by Lübeck",
   "Offices in London, Bruges, Bergen and Novgorod",
   "Hamburg is still officially a ‘Free and Hanseatic City’"
  ],
  "img": "assets/stories/hansa.webp",
  "ic": "Hanseatic towns, and their offices abroad.",
  "b": [
   "HH stands for Hansestadt Hamburg, the Hanseatic City of Hamburg. From the 1200s to the 1600s the Hanseatic League linked merchant towns around the North Sea and the Baltic, led by Lübeck and including Hamburg, Bremen, Danzig and Riga. It wasn’t a country but a trading club, with offices (kontors) in London, Bruges, Bergen and Novgorod. Its London base, the Steelyard, sat by the Thames where Cannon Street station is today.",
   "The League could still fight. In 1370 it defeated Denmark and won trading rights through the Treaty of Stralsund. Rising nation states and Atlantic trade eventually eclipsed it, but Hamburg and Bremen still officially call themselves ‘Free and Hanseatic’ cities, and their merchant pride remains."
  ],
  "w": "Hanseatic League"
 },
 {
  "k": "asml",
  "t": "Business",
  "q": "Why can only one company on Earth build the machine behind every top chip?",
  "m": "The world’s most strategic machine isn’t built by a superpower but by a company in a Dutch town most people have never heard of.",
  "tl": [
   "Only ASML makes EUV machines for the most advanced chips",
   "They cost over €150 million and take several planes to ship",
   "The Dutch haven’t allowed EUV sales to China since 2019"
  ],
  "img": "assets/stories/asml.webp",
  "ic": "Where an EUV machine comes together.",
  "b": [
   "Every advanced chip is printed with light, and the smallest features need extreme ultraviolet (EUV) light at 13.5 nanometres. Only ASML, based in Veldhoven in the Netherlands, makes EUV machines. Inside, a laser hits tiny droplets of molten tin tens of thousands of times a second to create the light, which is steered by Zeiss mirrors so smooth that, scaled up to the size of Germany, their biggest bump would be under a millimetre high.",
   "Each machine costs well over €150 million and ships in pieces in many containers and several cargo planes. It took decades and suppliers across Europe and the US to build, which is why no one has caught up. Since 2019 the Dutch government, under US pressure, has not allowed EUV sales to China."
  ],
  "w": "ASML Holding"
 },
 {
  "k": "panama",
  "t": "Shipping",
  "q": "How can a drought shut down an ocean shortcut?",
  "m": "One of the world’s great shipping routes runs on rainwater, and competes with a capital city for every drop.",
  "tl": [
   "Locks lift ships about 26 m to a rain-fed lake",
   "Each crossing lets about 200 million litres flow out to sea",
   "A 2023 drought cut crossings; one slot sold for nearly $4m"
  ],
  "img": "assets/stories/panama.webp",
  "ic": "Ships climb to Gatún Lake and back down, losing fresh water each time.",
  "b": [
   "The Panama Canal, opened in 1914, doesn’t cut through at sea level. Locks lift ships about 26 metres up to the man-made Gatun Lake, and each crossing lets roughly 200 million litres of fresh water flow out to the sea. The lake is filled by rain.",
   "In 2023 an El Niño drought left Gatun Lake so low that the canal cut daily crossings and limited how deep ships could sit. Queues formed, and one shipper paid nearly $4 million at auction to jump the line. The newer locks, opened in 2016 for bigger ‘Neopanamax’ ships, recycle much of their water in side basins, but the canal still depends on the same lake that supplies Panama City’s drinking water."
  ],
  "w": "Panama Canal"
 },
 {
  "k": "notpetya",
  "t": "Business",
  "q": "How did a power cut in Ghana save the world’s biggest shipping line?",
  "m": "A company carrying nearly a fifth of the world’s containers was saved not by its backup plan but by a lucky blackout.",
  "tl": [
   "NotPetya (2017) wiped Maersk’s computers worldwide",
   "One server survived because Ghana had a power cut",
   "Maersk rebuilt in about ten days at a cost of about $300m"
  ],
  "img": "assets/stories/notpetya.webp",
  "ic": "The Ghana backup made the trip to the UK, by way of Lagos.",
  "b": [
   "In June 2017 a piece of malware called NotPetya spread from a hacked Ukrainian accounting program. The US and UK later blamed Russia’s military. It looked like ransomware, but it simply destroyed data. Maersk was hit hard: its ports stalled, bookings stopped and staff went back to pen and paper while 76 terminals ground to a crawl.",
   "To rebuild, Maersk needed a copy of its network’s user directory, but every domain controller had been wiped except one in Ghana, which had been offline during a power cut. An employee flew it to the UK, and the company reinstalled around 4,000 servers and 45,000 PCs in about ten days. The attack cost Maersk roughly $300 million."
  ],
  "w": "2017 cyberattacks on Ukraine"
 },
 {
  "k": "galleon",
  "t": "History",
  "q": "When did globalisation really start? Try 1571.",
  "m": "Globalisation isn’t new: Chinese porcelain was turning up in Mexico City more than 400 years ago.",
  "tl": [
   "1571: Manila linked Asia and the Americas by regular trade",
   "American silver went west; silk and porcelain came back",
   "The Spanish silver dollar became the first global currency"
  ],
  "img": "assets/stories/galleon.webp",
  "ic": "The Manila galleons: west with the trade winds, back across the North Pacific.",
  "b": [
   "Some historians pick 1571, the year Spain founded Manila. From then until 1815, Spanish galleons sailed once or twice a year between Acapulco and Manila, carrying silver mined at places like Potosí in Bolivia. China, which wanted silver to pay its taxes, sent back silk and porcelain. For the first time every inhabited continent was linked by regular trade.",
   "The Spanish silver dollar, the ‘piece of eight’, became the world’s first global currency. It was used from China to the American colonies, and it shaped the US dollar itself. Chinese porcelain turned up in Mexico City and Peruvian silver in Beijing, a world economy long before steamships or the telegraph."
  ],
  "w": "Manila galleon"
 },
 {
  "k": "shipyards",
  "t": "Geopolitics",
  "q": "Why can’t America build ships any more?",
  "m": "The world’s biggest naval power can barely build commercial ships, and its own law makes the problem worse.",
  "tl": [
   "China builds about half of the world’s ships; the US under 1%",
   "The Jones Act forces US-built ships between US ports",
   "Washington is trying fees on Chinese ships and Korean investment"
  ],
  "img": "assets/stories/shipyards.webp",
  "ic": "Who builds the world’s ships, roughly.",
  "b": [
   "The US once had the world’s biggest shipyards, but today China builds roughly half of the world’s commercial ships, South Korea and Japan most of the rest, and the US well under 1%. A ship built in America can cost several times an Asian one, because of higher wages, older yards and a thin supplier base.",
   "The Jones Act of 1920 adds a twist: cargo between two US ports must travel on US-built, US-flagged ships with mostly American crews. That keeps some yards alive but makes shipping to Hawaii, Alaska and Puerto Rico costly. Washington’s latest tools include special port fees on Chinese-built ships, announced in 2025, and Korean investment, such as Hanwha buying Philadelphia’s shipyard in 2024."
  ],
  "w": "Merchant Marine Act of 1920"
 },
 {
  "k": "cherries",
  "t": "Trade",
  "q": "Why does China go wild for Chilean cherries every winter?",
  "m": "A fruit grown in the Andes owes its boom to a Chinese festival on the other side of the world.",
  "tl": [
   "Most Chilean cherries go to China",
   "Red cherries make a lucky New Year gift",
   "Peru’s new Chancay port shortens the trip to Asia"
  ],
  "img": "assets/stories/cherries.webp",
  "ic": "Cherry season lines up with Lunar New Year.",
  "b": [
   "Chile is the world’s biggest cherry exporter, and the overwhelming majority of its cherries go to China. The southern-hemisphere harvest lands just before Lunar New Year, and a box of deep-red cherries, red being the lucky colour, makes the perfect gift. Lines run special ‘cherry express’ reefer services to get them there fresh.",
   "Peru has gone further. In late 2024 the Chancay megaport opened north of Lima, majority-owned by China’s COSCO, with deep water for the biggest ships and faster direct routes to Asia. Its fruit and copper go west, and the empty reefers have to come back. That’s why lines discount any cargo that will fill them."
  ],
  "w": "Port of Chancay"
 },
 {
  "k": "ducks",
  "t": "Shipping",
  "q": "How did 28,800 bath toys help scientists map the ocean?",
  "m": "A shipping accident became one of oceanography’s best experiments, and a reminder of how much falls off ships.",
  "tl": [
   "A 1992 spill dumped 28,800 bath toys in the Pacific",
   "Scientists tracked where they landed to map currents",
   "Ships still lose around 1,500 containers a year"
  ],
  "img": "assets/stories/ducks.webp",
  "ic": "Where the toys went in the North Pacific.",
  "b": [
   "In January 1992 a container ship in a North Pacific storm lost several boxes overboard. One held 28,800 plastic bath toys: yellow ducks, blue turtles, green frogs and red beavers. Over the following years they washed up in Alaska and beyond, and oceanographer Curtis Ebbesmeyer used the reports of where and when they landed to study ocean currents.",
   "In 1997 a wave knocked a container holding nearly 5 million Lego pieces off the Tokio Express near Cornwall, and some still wash ashore there today. Ships still lose containers, on average around 1,500 a year by industry counts, usually in bad weather when stacks collapse."
  ],
  "w": "Friendly Floatees"
 },
 {
  "k": "shenzhen",
  "t": "Business",
  "q": "How did a border county become a 17-million-person tech capital in 40 years?",
  "m": "China’s most market-driven city was created on purpose by the Communist Party.",
  "tl": [
   "In 1980 it became one of China’s first Special Economic Zones",
   "Now 17+ million people, home to Huawei, Tencent and BYD",
   "Its port overtook Hong Kong’s as goods shipped direct"
  ],
  "img": "assets/stories/shenzhen.webp",
  "ic": "Shenzhen sits right across the border from Hong Kong.",
  "b": [
   "In 1980 Deng Xiaoping made Shenzhen, then a border county of a few hundred thousand people next to Hong Kong, one of China’s first Special Economic Zones. It was a place to experiment with foreign investment, land markets and exports. Hong Kong factory owners moved in, then Taiwanese, then everyone. ‘Shenzhen speed’ became a byword for building fast.",
   "Today it has more than 17 million people and is home to Huawei, Tencent, BYD and DJI. You can design, prototype and manufacture almost any electronic product within an hour’s drive. Its port is among the four busiest in the world, while Hong Kong’s, once the busiest anywhere, has slid down the rankings as goods now ship directly from the mainland."
  ],
  "w": "Shenzhen"
 },
 {
  "k": "codwars",
  "t": "Geopolitics",
  "q": "How did Iceland, with no army, beat the Royal Navy?",
  "m": "Iceland beat the Royal Navy without a real shot fired, because it held something NATO couldn’t do without.",
  "tl": [
   "Iceland kept pushing its fishing limit out, to 200 miles",
   "Coast guard boats cut British trawl nets; ships collided",
   "NATO leverage won it; the 200-mile zone became world law"
  ],
  "img": "assets/stories/codwars.webp",
  "ic": "Iceland’s fishing limits grew from 12 to 50 to 200 nautical miles.",
  "b": [
   "Fish are Iceland’s economy, and British trawlers were fishing them out. Iceland pushed its fishing limit from 4 to 12 nautical miles in 1958, then to 50 in 1972 and 200 in 1975. Britain sent warships to protect its trawlers. Icelandic coast guard boats cut trawl nets with special cutters, and ships rammed each other. These were the ‘Cod Wars’.",
   "Iceland’s trump card was NATO. It hinted it might close the US base at Keflavík, key to watching Soviet submarines, and in 1976 Britain backed down. The 200-mile exclusive economic zone became international law under the 1982 UN Convention on the Law of the Sea, while fishing towns like Hull and Grimsby never recovered."
  ],
  "w": "Cod Wars"
 },
 {
  "k": "quarantine",
  "t": "History",
  "q": "Why is quarantine 40 days, and who decided?",
  "m": "One of the oldest public-health rules was invented by trading cities to protect their trade, and the 40 days weren’t based on science.",
  "tl": [
   "Ragusa made ships wait 30 days in 1377",
   "Venice made it 40: ‘quaranta giorni’ gave us ‘quarantine’",
   "Forty was symbolic, not science"
  ],
  "img": "assets/stories/quarantine.webp",
  "ic": "Ragusa started with 30 days; Venice made it 40.",
  "b": [
   "During the Black Death, the port of Ragusa (now Dubrovnik) ordered in 1377 that ships from plague areas wait 30 days before landing, a ‘trentino’. Venice and other ports later extended it to 40 days, in Italian ‘quaranta giorni’, which gave us the word quarantine. Ports built isolation hospitals called lazarettos on nearby islands.",
   "Why forty? Nobody was counting incubation periods. The number had deep religious weight: forty days of Lent, Christ’s forty days in the desert, the forty days of the Flood. Even so, these were among the first public-health rules tied to trade: protecting a city without shutting down its port."
  ],
  "w": "Quarantine"
 },
 {
  "k": "air",
  "t": "Supply chain",
  "q": "If planes carry under 1% of trade, why do they matter so much?",
  "m": "The mode that moves the least stuff moves the most value. Your phone probably flew; your sofa sailed.",
  "tl": [
   "Air carries under 1% of trade by weight, a third by value",
   "It’s for light, valuable or perishable goods",
   "Half of it normally flies in passenger planes"
  ],
  "img": "assets/stories/air.webp",
  "ic": "Air carries little weight but a lot of value.",
  "b": [
   "Planes carry less than 1% of world trade by weight but roughly a third by value. Air is for things that are light, valuable or perishable: chips, phones, medicines, fashion samples, fresh fish, and cut flowers flown overnight from Kenya and Colombia. Per kilo it can cost dozens of times as much as sea freight, so it only makes sense when time matters more than money.",
   "About half of air cargo normally flies in the bellies of passenger jets. When flights were grounded in 2020, that capacity vanished overnight. Rates soared, and airlines flew empty passenger planes stuffed with boxes, sometimes strapped into the seats."
  ],
  "w": "Air cargo"
 },
 {
  "k": "hanjin",
  "t": "Business",
  "q": "What happens to $14 billion of cargo when its shipping line goes bust at sea?",
  "m": "In global shipping, cargo can be stranded not by storms but by unpaid bills.",
  "tl": [
   "Korea’s biggest line went bust in 2016",
   "Ports turned its ships away; $14bn of cargo was stuck",
   "It sped up consolidation into a few giant lines"
  ],
  "img": "assets/stories/hanjin.webp",
  "ic": "Hanjin’s ships waited outside ports that wouldn’t let them in.",
  "b": [
   "On 31 August 2016 Hanjin Shipping, Korea’s largest line, filed for receivership. Overnight, dozens of its ships became unwelcome: ports and terminals feared they would never be paid and refused to let them dock or unload. Roughly $14 billion of other companies’ cargo was stranded at sea, and crews were left waiting offshore for weeks as supplies ran low.",
   "Courts in the US and elsewhere had to step in to let ships unload, and retailers scrambled to recover goods before the holidays. Hanjin was liquidated in 2017. The shock sped up consolidation into a handful of giant lines, which is why a few alliances now control most container trade."
  ],
  "w": "Hanjin Shipping"
 },
 {
  "k": "singapore",
  "t": "Trade",
  "q": "Why do most containers in Singapore never actually enter Singapore?",
  "m": "One of the busiest ports on Earth is mostly a place where boxes change ships.",
  "tl": [
   "Raffles made it a tariff-free port in 1819",
   "Most boxes there just change ships",
   "A giant automated port at Tuas will replace the old terminals"
  ],
  "img": "assets/stories/singapore.webp",
  "ic": "Singapore is moving its port west, to Tuas.",
  "b": [
   "In 1819 Stamford Raffles set up a British trading post at the southern tip of the Strait of Malacca and made it a free port with no tariffs. The location was the point: nearly every ship between the Indian Ocean and the Pacific passes nearby.",
   "Today Singapore is the world’s biggest transshipment hub. The large majority of its boxes simply change ships there, arriving on a big Asia–Europe vessel and leaving on a smaller feeder to Indonesia, Vietnam or Bangladesh. The city is now moving all its terminals to a giant new automated port at Tuas, to be finished around 2040."
  ],
  "w": "Port of Singapore"
 },
 {
  "k": "scs",
  "t": "Geopolitics",
  "q": "Why is China turning reefs into islands?",
  "m": "A tribunal ruled the claim had no legal basis, and the islands kept getting built. At sea, law depends on who enforces it.",
  "tl": [
   "China claims most of the sea inside the ‘nine-dash line’",
   "It has turned reefs into islands with runways",
   "A 2016 tribunal rejected the claim; China ignores the ruling"
  ],
  "img": "assets/stories/scs.webp",
  "ic": "The disputed island groups of the South China Sea.",
  "b": [
   "China claims most of the South China Sea inside a ‘nine-dash line’ drawn in the 1940s, overlapping with claims by Vietnam, the Philippines, Malaysia, Brunei and Taiwan. The sea holds fish and gas, and a huge share of the world’s shipping passes through it. Since around 2013 China has turned reefs in the Spratly Islands into artificial islands with runways and harbours.",
   "In 2016 an international tribunal ruled, in a case brought by the Philippines, that the nine-dash line had no legal basis under the Law of the Sea. China rejected the ruling. What has followed is a slow contest of coast guards, fishing fleets and navy patrols over who controls the waters in practice."
  ],
  "w": "Territorial disputes in the South China Sea"
 },
 {
  "k": "zara",
  "t": "Business",
  "q": "How does Zara get a design into stores in weeks when rivals take months?",
  "m": "Zara pays more to make each item and still wins, because guessing wrong costs more than labour.",
  "tl": [
   "Zara makes much of its range near Spain, not in Asia",
   "New designs reach stores in a few weeks",
   "Higher unit cost, but less unsold stock"
  ],
  "img": "assets/stories/zara.webp",
  "ic": "Zara makes much of its clothing close to home.",
  "b": [
   "Most fashion brands order huge batches from Asia months ahead and hope they guess right. Inditex, Zara’s parent, founded by Amancio Ortega in Galicia, makes a large share of its clothing close to home, in Spain, Portugal, Morocco and Turkey, where it costs more per piece.",
   "In return it can take a new design from sketch to shop in a few weeks, ship small batches to stores twice a week and quickly make more of whatever sells. It discounts far less unsold stock than rivals. It is a supply-chain trade-off: higher unit cost for speed and less waste, which made Ortega one of the richest people in the world."
  ],
  "w": "Inditex"
 },
 {
  "k": "timezones",
  "t": "History",
  "q": "Why did America have two noons on one day in 1883?",
  "m": "The time on your clock isn’t set by the sun. It was set, largely, for train timetables.",
  "tl": [
   "Before 1883, every town kept its own sun time",
   "Railways created standard zones on 18 November 1883",
   "Greenwich became the prime meridian in 1884"
  ],
  "img": "assets/stories/timezones.webp",
  "ic": "The railways’ four zones were centred on these meridians.",
  "b": [
   "Until the 1880s every town kept its own time by the sun, so noon in Boston came about 12 minutes before noon in New York. For railways this was chaos, with dozens of different times on one timetable. On 18 November 1883, known as ‘the day of two noons’, North American railways switched to standard time zones, and towns reset their clocks.",
   "Canadian engineer Sandford Fleming campaigned for worldwide zones, and in 1884 an international conference in Washington chose Greenwich as the prime meridian. Congress didn’t make US time zones law until 1918. Every world clock on your screen traces back to trains."
  ],
  "w": "Time zone"
 },
 {
  "k": "teu",
  "t": "Supply chain",
  "q": "Why is the whole shipping world measured in 20-foot boxes?",
  "m": "One of the most powerful forces in the world economy is a boring agreement about box sizes.",
  "tl": [
   "Early container lines all used different box sizes",
   "ISO fixed 20- and 40-foot boxes in the 1960s",
   "Ships are measured in TEU: twenty-foot equivalent units"
  ],
  "img": "assets/stories/teu.webp",
  "ic": "The boxes that run the world.",
  "b": [
   "Early container companies each used their own size: McLean’s Sea-Land used 35-foot boxes, Matson in the Pacific used 24-foot ones. A box that only fits one company’s cranes and ships can’t become a global system. In the 1960s the International Organization for Standardization (ISO) settled on boxes 8 feet wide in 20- and 40-foot lengths, with standard corner fittings that lock to cranes, ships, trucks and trains.",
   "Capacity is still counted in TEU, twenty-foot equivalent units, even though most boxes today are 40-footers (2 TEU), and many are 9 ft 6 in ‘high cubes’. That boring standard is arguably one of the most important things that made globalisation work."
  ],
  "w": "Twenty-foot equivalent unit"
 },
 {
  "k": "bdi",
  "t": "Business",
  "q": "Why do economists watch what it costs to rent a cargo ship?",
  "m": "One of the most honest economic signals isn’t a share price; it’s what it costs to hire a ship to carry iron ore.",
  "tl": [
   "A daily price for hiring ships to carry ore, coal and grain",
   "It reflects real industrial demand",
   "It fell more than 90% in 2008"
  ],
  "img": "assets/stories/bdi.webp",
  "ic": "The index of bulk-ship hire costs through the 2008 crash.",
  "b": [
   "The Baltic Exchange began in 1744 at the Virginia and Baltick Coffee House in London, where merchants met to match cargoes with ships. Since 1985 it has published the Baltic Dry Index, a daily measure of what it costs to hire the big bulk ships that carry iron ore, coal and grain.",
   "Because nobody books a ship for iron ore unless a steel mill actually needs it, the index is a raw signal of industrial demand. In 2008 it fell more than 90% in about six months, one of the starkest warnings of the global crash. It is noisy, because new ships flood in and weather matters, but it is still one of the purest real-economy numbers out there."
  ],
  "w": "Baltic Dry Index"
 },
 {
  "k": "oil73",
  "t": "Geopolitics",
  "q": "How did one war make oil four times pricier in a few months?",
  "m": "Producers learned that supply could be a weapon, and importers spent decades making sure it wouldn’t work again.",
  "tl": [
   "Arab producers cut output and embargoed Israel’s backers",
   "Oil went from about $3 to $12 in months",
   "It created the IEA, oil reserves and North Sea drilling"
  ],
  "img": "assets/stories/oil73.webp",
  "ic": "The 1973 oil shock.",
  "b": [
   "In October 1973 Egypt and Syria attacked Israel in the Yom Kippur War. Arab oil producers cut output and embargoed countries that backed Israel, including the US and the Netherlands. Within months the oil price roughly quadrupled, from about $3 a barrel to around $12.",
   "Drivers queued for petrol, and several European countries, Denmark among them, banned Sunday driving. The shock created the International Energy Agency and strategic oil reserves, pushed Europe to drill the North Sea, and opened the US market to small, efficient Japanese cars. It also taught a lasting lesson: energy is foreign policy."
  ],
  "w": "1973 oil crisis"
 },
 {
  "k": "eic",
  "t": "History",
  "q": "How did a trading company end up with an army twice the size of Britain’s?",
  "m": "Britain’s rule in India began not as a government project but as a company answering to shareholders.",
  "tl": [
   "Chartered in 1600 to trade spices",
   "After Plassey (1757) it collected taxes across Bengal",
   "Its army was about twice Britain’s; the Crown took over in 1858"
  ],
  "img": "assets/stories/eic.webp",
  "ic": "Where the Company won India.",
  "b": [
   "Elizabeth I chartered the East India Company in 1600 to trade spices. Over 150 years it built forts, then armies of Indian soldiers led by British officers. After Robert Clive’s victory at Plassey in 1757, the Company won the right to collect taxes across Bengal, which made it a government in all but name.",
   "By the early 1800s its private army was roughly twice the size of the British Army. It ran much of India for profit until the 1857 rebellion, after which the British Crown took direct control in 1858. Historians often hold it up as the ultimate warning about what happens when a corporation becomes a state."
  ],
  "w": "East India Company"
 },
 {
  "k": "ikea",
  "t": "Business",
  "q": "What does a table with no legs have to do with IKEA’s empire?",
  "m": "IKEA’s empire rests on making you do part of the work, and selling that to you as a feature.",
  "tl": [
   "In 1956 a designer took the legs off a table to fit it in a car",
   "Flat-pack means less air shipped and stored",
   "IKEA designs to the box and the price first"
  ],
  "img": "assets/stories/ikea.webp",
  "ic": "Flat-pack ships far less air.",
  "b": [
   "In 1956 an IKEA designer, Gillis Lundgren, couldn’t fit a table into a car after a photo shoot, so he took its legs off. The idea stuck. Flat-pack means far less air shipped across the world, more products per container and truck, cheaper warehouses, and customers doing the final assembly themselves.",
   "IKEA was founded in 1943 by Ingvar Kamprad, and the name is his initials plus Elmtaryd, the family farm, and Agunnaryd, his home village in Sweden. The whole business is built backwards from the box: products are designed to a price and a package size, and then made to look good."
  ],
  "w": "Flat-pack furniture"
 },
 {
  "k": "ballast",
  "t": "Shipping",
  "q": "How did a ship’s ballast water cost the Great Lakes billions?",
  "m": "A ship can carry a cargo nobody loaded that ends up costing more than everything it was paid to move.",
  "tl": [
   "Ships carry seawater as ballast, and life with it",
   "Zebra mussels reached the Great Lakes this way",
   "Since 2017, ships must treat ballast water"
  ],
  "img": "assets/stories/ballast.webp",
  "ic": "Zebra mussels rode in ballast water from the Black Sea region.",
  "b": [
   "Empty ships pump seawater into ballast tanks to stay stable and pump it out when they load cargo. Along with the water come fish, larvae and plankton from the other side of the world. Zebra mussels from the Black and Caspian Sea region arrived in the Great Lakes this way in the late 1980s.",
   "They spread fast, covering water-intake pipes at power plants and treatment works and costing billions to clear. In 2017 an International Maritime Organization treaty came into force requiring ships to treat ballast water, with filters, ultraviolet light or chemicals, before discharging it."
  ],
  "w": "Ballast water discharge and the environment"
 },
 {
  "k": "chips",
  "t": "Supply chain",
  "q": "How could one cheap chip stop a whole car factory?",
  "m": "The cheapest part can stop the whole product, because nobody can sell a car that’s 99% finished.",
  "tl": [
   "Carmakers cancelled chip orders in 2020",
   "Fabs gave the capacity to booming electronics",
   "One missing chip can stop a whole car line"
  ],
  "img": "assets/stories/chips.webp",
  "ic": "How the 2021 chip shortage happened.",
  "b": [
   "When Covid hit in 2020, carmakers expected a slump and cancelled chip orders. At the same time, everyone stuck at home bought laptops, consoles and webcams, and the foundries happily gave the spare capacity to electronics firms. When car sales bounced back months later, the factories were full.",
   "A modern car can contain more than a thousand chips, many of them cheap, older designs, and missing just one stops the line. Automakers built millions fewer cars in 2021, and Ford and GM parked unfinished trucks in fields waiting for parts. The lesson: the cheapest component in a product can decide whether it gets made at all."
  ],
  "w": "2020–2023 global chip shortage"
 },
 {
  "k": "dejima",
  "t": "History",
  "q": "How did one tiny artificial island become Japan’s only window on the West?",
  "m": "Japan’s ‘closed country’ was never fully closed. It kept one tightly controlled window, and learned through it.",
  "tl": [
   "Japan closed itself to most foreigners in the 1630s",
   "The Dutch could trade, but only from Dejima",
   "Perry’s ‘black ships’ forced Japan open in 1853–54"
  ],
  "img": "assets/stories/dejima.webp",
  "ic": "Dejima in Nagasaki, and where Perry arrived in 1853.",
  "b": [
   "In the 1630s Japan’s Tokugawa shogunate, wary of Christianity and foreign meddling, sharply limited contact with the outside world. The Portuguese were expelled in 1639. The Dutch, who cared about trade rather than converts, were allowed to stay, but only on Dejima, a small fan-shaped artificial island in Nagasaki harbour, from 1641.",
   "For over two centuries Dejima was almost Japan’s only window on European trade and science. Japanese scholars studied ‘Dutch learning’, including anatomy, medicine and astronomy, through books that came in on the ships. The arrangement ended after the American Commodore Perry’s ‘black ships’ forced Japan open in 1853–54."
  ],
  "w": "Dejima"
 },
 {
  "k": "spiral",
  "t": "Trade",
  "q": "Did a tariff make the Great Depression worse?",
  "m": "Tariffs meant to protect jobs during a slump helped shrink the trade those jobs depended on.",
  "tl": [
   "The 1930 US tariff raised duties on 20,000+ goods",
   "Trade partners retaliated; world trade collapsed",
   "It’s why the GATT and WTO were built"
  ],
  "img": "assets/stories/spiral.webp",
  "ic": "World imports collapsed month by month from 1929 to 1933.",
  "b": [
   "In 1930, as the Depression deepened, the US passed the Smoot–Hawley Tariff Act, raising duties on more than 20,000 imported goods. Over a thousand economists had begged President Hoover to veto it. Canada, Europe and others retaliated with tariffs of their own.",
   "World trade collapsed in the early 1930s. Economists still argue over how much the tariffs caused, since falling prices and incomes did a lot of the damage, but the episode became a lesson. In 1934 Congress handed tariff-cutting power to the president, and after the war the GATT, later the WTO, was built to stop tit-for-tat tariff wars."
  ],
  "w": "Smoot–Hawley Tariff Act"
 },
 {
  "k": "greek",
  "t": "Business",
  "q": "Why does a country of 10 million own about a fifth of the world’s ships?",
  "m": "A small country with a modest economy controls one of the most global industries on Earth.",
  "tl": [
   "Greek owners control about a fifth of world shipping",
   "Island families built the tradition",
   "Cheap post-war Liberty ships launched the modern fleets"
  ],
  "img": "assets/stories/greek.webp",
  "ic": "The islands that bred Greece’s shipowning families.",
  "b": [
   "Greek owners control the largest merchant fleet in the world by carrying capacity, close to a fifth of the global total, though many ships fly other flags. The roots go back to seafaring islands like Chios, Andros and Kasos, where shipowning families passed down know-how and money.",
   "After the Second World War, the US sold surplus Liberty ships cheaply and Greek owners bought them by the dozen, the same years in which Aristotle Onassis and Stavros Niarchos built their empires. Greek shipping specialises in tramp shipping (oil tankers and bulk carriers that go wherever the cargo is), and its owners have a reputation for buying ships cheap in downturns and selling high in booms."
  ],
  "w": "Greek shipping"
 },
 {
  "k": "arctic",
  "t": "Geopolitics",
  "q": "Will melting ice open a shortcut to Asia over the top of Russia?",
  "m": "Climate change may open a faster trade route, and the country that would control it is Russia.",
  "tl": [
   "The Arctic route is about a third shorter to Asia",
   "It is open only a few months and needs ice-class ships",
   "Russia controls it; traffic is mostly Russian energy"
  ],
  "img": "assets/stories/arctic.webp",
  "ic": "The Northern Sea Route against the Suez route.",
  "b": [
   "The Northern Sea Route runs along Russia’s Arctic coast and can make Europe–East Asia voyages roughly a third shorter than going via Suez. As the ice retreats, it is open for longer each summer.",
   "It is still no Suez. The season is only a few months, ships need ice-strengthening or icebreaker escorts, insurance is expensive, there are few ports for repairs, and Russia controls access. Most traffic is Russian oil and LNG rather than containers, and after 2022 Western lines mostly stayed away. It’s a route to watch, not yet one to plan around."
  ],
  "w": "Northern Sea Route"
 },
 {
  "k": "clippers",
  "t": "History",
  "q": "How did a canal kill the fastest sailing ships ever built?",
  "m": "Technology made the best sailing ships obsolete within a few years; being the best at the old way isn’t safe.",
  "tl": [
   "Tea clippers raced from China to London in the 1860s",
   "Suez opened in 1869 and suited steamships, not sails",
   "The Cutty Sark switched to wool, and is now in Greenwich"
  ],
  "img": "assets/stories/clippers.webp",
  "ic": "Clippers sailed round the Cape; after 1869, steamers went via Suez.",
  "b": [
   "In the 1850s and 60s sleek tea clippers raced from China to London, and the first tea of the season sold at a premium. The Great Tea Race of 1866 ended with ships docking within hours of each other after three months at sea. The Cutty Sark, one of the fastest, was launched in Scotland in November 1869.",
   "That same month the Suez Canal opened. Steamships could now take the short route, while sailing ships struggled with the Red Sea’s winds and needed tugs through the canal. Within a few years the clippers lost the tea trade, and the Cutty Sark switched to carrying wool from Australia. She now sits in dry dock at Greenwich."
  ],
  "w": "Cutty Sark"
 },
 {
  "k": "maersk",
  "t": "Business",
  "q": "How did a captain’s son from a small Danish town build a shipping giant?",
  "m": "A family firm from a provincial Danish town became a backbone of globalisation, and a foundation still controls it.",
  "tl": [
   "Founded in Svendborg in 1904 by A.P. Møller and his father",
   "Long the biggest container line; MSC passed it in 2022",
   "Its bet now is end-to-end logistics"
  ],
  "img": "assets/stories/maersk.webp",
  "ic": "From Svendborg to Copenhagen.",
  "b": [
   "A.P. Møller founded his shipping company in Svendborg, Denmark, in 1904, together with his father, the sea captain Peter Mærsk Møller. It grew into A.P. Møller–Maersk, for decades the world’s largest container line, still controlled by a family foundation. Denmark’s long seafaring tradition also produced lines like DFDS, Torm and Norden.",
   "In 2022 Geneva-based MSC overtook Maersk in fleet size. Maersk’s bet has been to become an end-to-end logistics company, with warehouses, trucking and air freight, rather than chase ever more ships. Its light-blue hulls and white seven-pointed star are recognised in ports worldwide."
  ],
  "w": "Maersk"
 },
 {
  "k": "liner",
  "t": "Shipping",
  "q": "Is your container riding a bus or a taxi?",
  "m": "Container shipping is really a timetable business; the boxes are almost secondary to the schedule.",
  "tl": [
   "Liner: fixed routes and weekly schedules, like a bus",
   "Tramp: hired to go wherever the cargo is, like a taxi",
   "Lines share ships in alliances; Gemini started in 2025"
  ],
  "img": "assets/stories/liner.webp",
  "ic": "A liner loop against a one-off tramp voyage.",
  "b": [
   "Liner shipping works like a bus: fixed routes, published schedules and set ports, every week whether the ship is full or not. Almost all container shipping is liner shipping, which is why shippers can plan, and why lines care so much about being reliable. Tramp shipping works like a taxi: bulk carriers and tankers are hired for one voyage or a period and go wherever the cargo is.",
   "To run a weekly service on a long route you might need a dozen ships, so lines share space in alliances. In 2025 Maersk and Hapag-Lloyd launched the Gemini Cooperation, while MSC chose to sail mostly alone. Who partners with whom quietly decides which ports win."
  ],
  "w": "Liner service"
 },
 {
  "k": "chinashock",
  "t": "Trade",
  "q": "Why did cheaper TVs cost some American towns their jobs?",
  "m": "Trade made almost everyone a little better off and some places much worse off, which is why it’s good economics and hard politics.",
  "tl": [
   "China joined the WTO in December 2001",
   "Exports soared and goods got cheaper everywhere",
   "Exposed US towns lost jobs that didn’t come back"
  ],
  "img": "assets/stories/chinashock.webp",
  "ic": "China’s WTO entry and the export surge that followed.",
  "b": [
   "China joined the World Trade Organization in December 2001 after 15 years of talks. With lower tariffs and the security of WTO rules, foreign firms poured in, and Chinese exports soared. Shoppers everywhere got cheaper furniture, electronics and clothes.",
   "Economists David Autor, David Dorn and Gordon Hanson later showed that the US towns most exposed to Chinese competition lost manufacturing jobs that didn’t come back, with estimates of roughly two million jobs over a decade. Their work on the ‘China shock’ changed how economists talk about trade: the gains are real and spread widely, while the losses are concentrated in particular places."
  ],
  "w": "China shock"
 },
 {
  "k": "tordesillas",
  "t": "History",
  "q": "Why does Brazil speak Portuguese when its neighbours speak Spanish?",
  "m": "Two countries carved up the world with a line on a map, and that line still decides what language 200 million people speak.",
  "tl": [
   "In 1494 Spain and Portugal split the world with a line",
   "Brazil’s eastern bulge fell on Portugal’s side",
   "So Brazil speaks Portuguese"
  ],
  "img": "assets/stories/tordesillas.webp",
  "ic": "The 1494 line put Brazil’s bulge on Portugal’s side.",
  "b": [
   "After Columbus’s first voyage, Spain and Portugal, with the Pope’s blessing, divided the newly discovered world between them. The 1494 Treaty of Tordesillas drew a north–south line 370 leagues west of the Cape Verde islands: Spain got the lands to the west, Portugal those to the east.",
   "Nobody knew it yet, but the eastern bulge of South America lay on Portugal’s side. When Pedro Álvares Cabral landed there in 1500, Portugal claimed it, and that is how Brazil came to speak Portuguese while its neighbours speak Spanish. England, France and the Netherlands simply ignored the treaty."
  ],
  "w": "Treaty of Tordesillas"
 },
 {
  "k": "airlift",
  "t": "Geopolitics",
  "q": "How do you feed two million people entirely by plane?",
  "m": "The Cold War’s first big standoff was won by logistics, not combat.",
  "tl": [
   "In 1948 the Soviets cut all land routes into West Berlin",
   "The allies flew in about 2.3 million tonnes over 11 months",
   "At the peak, a plane landed every minute or so"
  ],
  "img": "assets/stories/airlift.webp",
  "ic": "Three air corridors fed West Berlin.",
  "b": [
   "In June 1948 the Soviet Union cut every road, rail and canal link into West Berlin, trying to force the Western allies out. Rather than fight, the US and Britain flew in everything 2 million people needed. Mostly that meant coal, plus food and medicine.",
   "Over about eleven months they delivered around 2.3 million tonnes. On one Easter Sunday in 1949 they flew nearly 1,400 flights in 24 hours, with planes landing every minute or so. Pilot Gail Halvorsen dropped sweets on tiny parachutes for children. In May 1949 the Soviets lifted the blockade, a logistics victory that shaped the Cold War."
  ],
  "w": "Berlin Blockade"
 },
 {
  "k": "norway",
  "t": "Business",
  "q": "How did Norway get rich from oil without the oil curse?",
  "m": "The best way to get rich from oil turned out to be acting as if you didn’t have it: invest abroad, spend slowly.",
  "tl": [
   "‘Dutch disease’: a resource boom hurts everything else",
   "Norway invests its oil money abroad and spends only ~3% a year",
   "The fund owns about 1.5% of the world’s listed shares"
  ],
  "img": "assets/stories/norway.webp",
  "ic": "North Sea oil, and the Dutch gas field that named a ‘disease’.",
  "b": [
   "In 1977 The Economist coined ‘Dutch disease’ for what happened after the Netherlands found huge gas reserves: export money pushed up the currency and made its factories uncompetitive. A resource boom can hollow out the rest of an economy.",
   "Norway struck oil in 1969 and chose a different path. Its oil fund, set up in 1990, invests the money only abroad, so it doesn’t inflate the krone, and the government normally spends only about 3% of the fund each year. The fund is now worth well over a trillion dollars and owns roughly 1.5% of all listed shares on Earth."
  ],
  "w": "Government Pension Fund of Norway"
 },
 {
  "k": "somalia",
  "t": "Geopolitics",
  "q": "How did the world beat the Somali pirates?",
  "m": "Piracy wasn’t beaten by catching pirates. It ended when it stopped paying.",
  "tl": [
   "Pirates peaked around 2009–2011 in the Gulf of Aden",
   "Patrols, razor wire, citadels and armed guards stopped them",
   "Once it stopped paying, it largely stopped"
  ],
  "img": "assets/stories/somalia.webp",
  "ic": "The Gulf of Aden, on the way to Suez.",
  "b": [
   "Around 2009–2011, pirates from Somalia’s coast were hijacking ships in the Gulf of Aden and far out into the Indian Ocean, holding crews for ransoms of millions of dollars. The route matters: it leads to the Red Sea and Suez.",
   "The answer was a mix of measures. EU, NATO and other navies patrolled a protected shipping corridor. Ships added razor wire, sailed faster and built locked ‘citadels’ for crews, and many hired armed guards. No ship carrying armed guards was successfully hijacked. Attacks fell close to zero, though they have occasionally flared up since. Piracy is a business, and it stopped when it stopped paying."
  ],
  "w": "Piracy off the coast of Somalia"
 },
 {
  "k": "mulberry",
  "t": "History",
  "q": "How did the Allies bring their own harbours to D-Day?",
  "m": "D-Day depended as much on engineers and concrete as on soldiers.",
  "tl": [
   "The Allies needed a port in Normandy and didn’t have one",
   "So they built two harbours and towed them across",
   "A storm wrecked one; the other ran for months"
  ],
  "img": "assets/stories/mulberry.webp",
  "ic": "The harbours were towed from Britain to Normandy.",
  "b": [
   "To invade France in 1944, the Allies needed a port, but every big harbour was heavily defended. So they built two harbours in Britain and towed them across the Channel: huge concrete caissons, floating roadways and old ships sunk as breakwaters. These were the Mulberry harbours.",
   "A storm in late June wrecked the American Mulberry off Omaha Beach, but the British one at Arromanches worked for months, landing millions of tonnes of supplies, plus troops and vehicles. Its broken concrete blocks are still visible offshore. It was a reminder that wars are won as much by supply lines as by battles."
  ],
  "w": "Mulberry harbour"
 },
 {
  "k": "kiel",
  "t": "Shipping",
  "q": "Which canal is busier than Suez and Panama? One in Germany.",
  "m": "The world’s busiest artificial waterway is one most people have never heard of.",
  "tl": [
   "98 km across northern Germany, opened in 1895",
   "Saves about 460 km around Denmark",
   "The busiest artificial waterway by number of ships"
  ],
  "img": "assets/stories/kiel.webp",
  "ic": "The canal saves ships the long way round Denmark.",
  "b": [
   "Not Suez or Panama, at least by number of ships, but Germany’s Kiel Canal. Opened in 1895, it runs 98 km across Schleswig-Holstein from the Elbe estuary near Hamburg to Kiel on the Baltic, saving ships a voyage of around 460 km around Denmark’s northern tip.",
   "It was built partly so the Imperial Navy could move warships between the North Sea and the Baltic without passing foreign waters. After the First World War the Treaty of Versailles opened it to all nations. Today tens of thousands of mostly smaller ships use it each year: feeders, ferries and bulk carriers linking Hamburg to Scandinavia and the Baltic."
  ],
  "w": "Kiel Canal"
 },
 {
  "k": "posh",
  "t": "History",
  "q": "Does ‘posh’ really stand for ‘port out, starboard home’?",
  "m": "The neatest explanations in history are often the ones invented after the fact.",
  "tl": [
   "The story says P&O tickets were stamped P.O.S.H.",
   "No such ticket has ever been found",
   "It is almost certainly a myth"
  ],
  "img": "assets/stories/posh.webp",
  "ic": "The supposed reason: the shady side of the ship each way.",
  "b": [
   "The story goes that rich passengers sailing between Britain and India with P&O booked cabins on the shady side of the ship: port side out, starboard side home. Their tickets were supposedly stamped P.O.S.H.",
   "It is almost certainly a myth. No ticket with ‘POSH’ on it has ever been found, P&O has no record of it, and dictionaries treat the explanation as a backronym, invented after the word already existed. The real origin is unknown, though ‘posh’ was 19th-century slang for money or for a dandy. It’s a good reminder that the neatest stories about history are often the least true."
  ],
  "w": "Posh"
 },
 {
  "k": "bretton",
  "t": "Geopolitics",
  "q": "Why does the whole world run on American dollars?",
  "m": "The dollar lost its link to gold in 1971 and became more central to the world, not less.",
  "tl": [
   "1944: currencies pegged to the dollar, the dollar to gold",
   "1971: Nixon ended the gold link",
   "The dollar still dominates trade, oil and reserves"
  ],
  "img": "assets/stories/bretton.webp",
  "ic": "How the 1944 system tied money to gold, until 1971.",
  "b": [
   "In July 1944 delegates from 44 countries met at Bretton Woods, New Hampshire. They pegged their currencies to the US dollar, which could be swapped for gold at $35 an ounce, and created the IMF and the World Bank. The US had most of the world’s gold and its strongest economy.",
   "By 1971 there were far more dollars abroad than gold to back them, and on 15 August Nixon ended gold convertibility, the ‘Nixon shock’. Currencies have floated ever since, yet the dollar stayed on top: most trade, oil and debt are priced in it, and it remains the main reserve currency. That gives the US cheap borrowing and the power to cut countries off with sanctions."
  ],
  "w": "Bretton Woods system"
 },
 {
  "k": "panamax",
  "t": "Shipping",
  "q": "Why are ships built to the size of a canal?",
  "m": "Ships are designed backwards from canals, so locks built in 1914 shaped ships for a century.",
  "tl": [
   "Ship classes are named for the waterways they fit",
   "Panamax is about 32 m wide; Neopanamax about 51 m",
   "The biggest ships are too wide for Panama, so they use Suez"
  ],
  "img": "assets/stories/panamax.webp",
  "ic": "Ship widths against the Panama locks, to scale.",
  "b": [
   "Ship designers often start with a waterway and build the biggest thing that fits. A ‘Panamax’ ship fit the original Panama Canal locks, about 32 metres wide, which shaped a generation of vessels. Since the larger locks opened in 2016, ‘Neopanamax’ ships up to about 51 metres wide can pass. ‘Suezmax’ tankers are as deep as Suez allows, and ‘Malaccamax’ the deepest that can clear the Strait of Malacca.",
   "The biggest container ships today are about 400 metres long and over 60 metres wide, too big for Panama, so they work Asia–Europe via Suez. Port depth, cranes and bridges have to keep up, which is part of why some old ports lose out as ships keep growing."
  ],
  "w": "Panamax"
 },
 {
  "k": "apple",
  "t": "Supply chain",
  "q": "Why are iPhones made in China, and can that change?",
  "m": "One of the world’s most valuable companies depends on a country its own government is at odds with, and leaving takes years.",
  "tl": [
   "Zhengzhou’s ‘iPhone City’ once employed a few hundred thousand",
   "Cook says the draw is skill and scale, not cheap labour",
   "Since 2022 Apple has moved more assembly to India and Vietnam"
  ],
  "img": "assets/stories/apple.webp",
  "ic": "Where iPhones are assembled.",
  "b": [
   "At its peak, Foxconn’s plant in Zhengzhou, nicknamed ‘iPhone City’, employed a few hundred thousand workers. Local government helped with buildings, roads and air cargo links. Tim Cook has argued the draw isn’t cheap labour but skill and scale: vast numbers of tooling engineers and suppliers within a short drive.",
   "In late 2022 Covid lockdowns and worker protests at Zhengzhou cut iPhone output just before the holidays, and rising US–China tension added to the risk. Apple has since pushed more assembly to India, where Foxconn and Tata build iPhones, and to Vietnam. Moving a supply chain that dense takes years, not months."
  ],
  "w": "Foxconn"
 },
 {
  "k": "ecsc",
  "t": "History",
  "q": "Why did the EU start out as a coal and steel deal?",
  "m": "The EU began as a plan to make war physically impossible by tying two countries’ war industries together.",
  "tl": [
   "In 1950 Schuman proposed pooling French and German coal and steel",
   "Six countries signed in 1951",
   "It grew into the European Union"
  ],
  "img": "assets/stories/ecsc.webp",
  "ic": "The six founders of the European Coal and Steel Community.",
  "b": [
   "Five years after the Second World War, French foreign minister Robert Schuman proposed, on 9 May 1950, putting French and German coal and steel under one shared authority. Those were the raw materials of tanks and guns, so pooling them would make another war between the two ‘not merely unthinkable, but materially impossible’.",
   "Six countries signed the Treaty of Paris in 1951, creating the European Coal and Steel Community, an idea largely designed by Jean Monnet. It grew into the European Economic Community in 1957 and the European Union in 1993. Peace was built through trade: make neighbours depend on each other, and fighting becomes self-defeating."
  ],
  "w": "European Coal and Steel Community"
 },
 {
  "k": "hapaglloyd",
  "t": "Business",
  "q": "How did Hapag-Lloyd survive losing its whole fleet twice?",
  "m": "A company that lost its entire fleet twice is still one of the biggest in its industry.",
  "tl": [
   "HAPAG lost its fleet after both world wars",
   "In 2008 Hamburg and Kühne kept it from a Singapore takeover",
   "Chilean, Qatari and Saudi shareholders came later"
  ],
  "img": "assets/stories/hapaglloyd.webp",
  "ic": "Hapag-Lloyd’s near-death moments.",
  "b": [
   "After the First World War, HAPAG lost almost its entire fleet to reparations, and Albert Ballin, who had built it, died days before the armistice. It rebuilt, only to lose its ships again after the Second World War.",
   "The most recent close call came in 2008. Its owner, the travel group TUI, put it up for sale, and Singapore’s NOL bid for it. The City of Hamburg and logistics billionaire Klaus-Michael Kühne formed a consortium, named after Ballin, to keep it in Hamburg. Later mergers with Chile’s CSAV (2014) and the Gulf’s UASC (2017) brought in Chilean, Qatari and Saudi shareholders, but the head office never left the city."
  ],
  "w": "Hapag-Lloyd"
 },
 {
  "k": "hamburger",
  "t": "History",
  "q": "Is the hamburger really from Hamburg?",
  "m": "America’s most American food is named after a German port, and nobody can prove who invented it.",
  "tl": [
   "‘Hamburg steak’ was minced beef linked to the city",
   "Emigrant ships may have carried the taste to New York",
   "Who first put it in a bun is still disputed"
  ],
  "img": "assets/stories/hamburger.webp",
  "ic": "Four American towns claim the first hamburger in a bun.",
  "b": [
   "The name is, sort of. In the 1800s ‘Hamburg steak’ (minced, seasoned beef) was associated with the city, and the popular story says emigrants sailing to New York on Hamburg lines brought the taste with them. New York restaurants advertised ‘Hamburg-style’ steak to attract German customers.",
   "Who first put it in a bun is fiercely disputed. Towns in Wisconsin, Texas, New York and Connecticut all claim it, and nobody can prove anything. What is certain is that a dish named after a port became one of the most globalised foods on Earth, now served in Hamburg as an American import."
  ],
  "w": "Hamburger"
 }
];
