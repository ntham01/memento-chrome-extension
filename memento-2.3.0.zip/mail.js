// Inbox panel: the 5 newest unread emails from Gmail, read from Gmail's own inbox feed
// using the account you're signed into in Chrome. No setup or passwords.
(() => {
  "use strict";
  const C = window.MEMENTO_CONFIG;
  const $ = (id) => document.getElementById(id);
  const FEED = (C.gmailFeedUrl || "https://mail.google.com/mail/feed/atom");
  const GMAIL = (C.gmailUrl || "https://mail.google.com/mail/u/0/#inbox");
  const MAX = 5, ROW_H = 28, MIN = 6e4;
  const store = chrome && chrome.storage && chrome.storage.local;

  $("mailOpen").href = GMAIL;
  let cache = null;

  // how many rows fit between the calendar and the to-do list (fixed per window size, never by content)
  function rowsThatFit() {
    const box = $("mailList").getBoundingClientRect();
    return Math.max(0, Math.min(MAX, Math.floor((box.height + 1) / ROW_H)));
  }

  const fmtWhen = (ms) => {
    const d = new Date(ms), now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (sameDay) return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    if (d.toDateString() === y.toDateString()) return "Yesterday";
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  };

  function render() {
    const list = $("mailList"), note = $("mailNote");
    const rows = cache && cache.mails ? cache.mails.slice(0, rowsThatFit()) : [];
    list.replaceChildren(...rows.map(m => {
      const li = document.createElement("li");
      const a = document.createElement("a");
      a.href = m.link || GMAIL; a.target = "_blank"; a.rel = "noopener";
      a.title = `${m.from}${m.email ? " <" + m.email + ">" : ""}\n${m.subject}\n${fmtWhen(m.time)}${m.summary ? "\n\n" + m.summary : ""}`;
      const who = document.createElement("span"); who.className = "mail-from"; who.textContent = m.from;
      const what = document.createElement("span"); what.className = "mail-subject"; what.textContent = m.subject || "(no subject)";
      a.append(who, what); li.append(a); return li;
    }));
    note.textContent = !cache ? "Loading…" : cache.error === "signin" ? "Sign in to Gmail to see your inbox." : cache.error ? "Couldn’t reach Gmail." : rows.length ? "" : "No unread email.";
  }

  async function refresh() {
    try {
      const res = await fetch(FEED, { credentials: "include", cache: "no-store" });
      if (res.status === 401 || res.status === 403) throw Object.assign(new Error("signin"), { kind: "signin" });
      if (!res.ok) throw new Error(String(res.status));
      const xml = new DOMParser().parseFromString(await res.text(), "application/xml");
      if (xml.querySelector("parsererror")) throw Object.assign(new Error("signin"), { kind: "signin" });   // a sign-in page, not the feed
      const txt = (el, sel) => (el.querySelector(sel) || {}).textContent || "";
      const mails = [...xml.querySelectorAll("entry")].map(e => ({
        subject: txt(e, "title").trim(),
        summary: txt(e, "summary").trim(),
        from: txt(e, "author > name").trim() || txt(e, "author > email").trim(),
        email: txt(e, "author > email").trim(),
        time: Date.parse(txt(e, "issued") || txt(e, "modified")) || Date.now(),
        link: ((e.querySelector("link") || {}).getAttribute ? e.querySelector("link").getAttribute("href") : "").replace(/^http:/, "https:")
      })).sort((a, b) => b.time - a.time);
      cache = { mails, count: parseInt(txt(xml, "fullcount"), 10) || mails.length, at: Date.now() };
    } catch (err) {
      cache = { mails: [], count: null, error: err.kind === "signin" ? "signin" : "error", at: Date.now() };
    }
    if (store) store.set({ mailCache: cache });
    render();
  }

  (async () => {
    if (store) cache = (await store.get("mailCache")).mailCache || null;   // last copy shows instantly
    render();
    refresh();
    setInterval(() => { if (!document.hidden) refresh(); }, 2 * MIN);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
    addEventListener("resize", render);
  })();
  window.__mementoMail = { refresh, render };
})();
