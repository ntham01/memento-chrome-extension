// Example quotes. Copy this file to quotes.js and replace them with your own.
// quotes.js is git-ignored. Leave "c" empty for no credit line; anything over maxQuoteLength is skipped.
window.MEMENTO_QUOTES = [
  { q: "Memento mori.", c: "Latin proverb" },
  { q: "It is not that we have a short time to live, but that we waste a great deal of it.", c: "Seneca" },
  { q: "We suffer more often in imagination than in reality.", c: "Seneca" },
  { q: "Waste no more time arguing what a good man should be. Be one.", c: "Marcus Aurelius" },
  { q: "Well begun is half done.", c: "Aristotle" },
  { q: "Know thyself.", c: "Delphic maxim" },
  { q: "Lost time is never found again.", c: "Benjamin Franklin" },
  { q: "Do what you can, with what you have, where you are.", c: "Theodore Roosevelt" },
  { q: "Start before you're ready.", c: "" }
];
