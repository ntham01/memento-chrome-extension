// Today's save: one post from your Instagram saves per day, shown under the bookmark icon.
// The list comes from saves.js (built from your Instagram data export).
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const saves = window.MEMENTO_SAVES || [];
  const btn = $("saveBtn"), panel = $("savePanel");
  if (!saves.length) { btn.hidden = true; return; }

  // Same post all day; a fixed shuffle so it works through every save before repeating.
  const dayNumber = (d) => Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  const order = saves.map((_, i) => i);
  let seed = 20050404;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
  for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  const today = () => saves[order[dayNumber(new Date()) % order.length]];

  const key = "memento:seenSave";
  const seenToday = () => { try { return localStorage.getItem(key) === String(dayNumber(new Date())); } catch { return false; } };
  const markSeen = () => { try { localStorage.setItem(key, String(dayNumber(new Date()))); } catch {} $("saveDot").hidden = true; };

  let shownCode = "";
  function fill() {
    const s = today();
    const url = `https://www.instagram.com/${s.k === "reel" ? "reel" : "p"}/${s.c}/`;
    if (shownCode !== s.c) {
      shownCode = s.c;
      $("saveFrame").src = `https://www.instagram.com/p/${s.c}/embed/`;
    }
    $("saveOpen").href = url;
    $("saveCaption").textContent = s.t || "";
    $("saveBy").textContent = s.u ? `@${s.u}` : "";
    $("saveCol").textContent = s.col && s.col.length ? s.col.join(", ") : "";
  }

  function open() { fill(); panel.hidden = false; btn.setAttribute("aria-expanded", "true"); markSeen(); }
  function close() { panel.hidden = true; btn.setAttribute("aria-expanded", "false"); }
  const toggle = () => (panel.hidden ? open() : close());

  btn.addEventListener("click", (e) => { e.stopPropagation(); toggle(); });
  document.addEventListener("click", (e) => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) close(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.hidden) { close(); btn.focus(); return; }
    if (e.target.closest("input, textarea, [contenteditable]") || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === "b" || e.key === "B") toggle();
  });

  $("saveDot").hidden = seenToday();
  window.__mementoSaves = { today, open, close };
})();
