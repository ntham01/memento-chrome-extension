// Personal settings. Edit these and reload the new tab.
window.MEMENTO_CONFIG = {
  name: "Chuch",
  birthday: "2005-04-04",        // YYYY-MM-DD
  lifeYears: 80,                 // grid is lifeYears x 52 weeks
  notionUrl: "https://app.notion.com/p/Home-62cdf963040d40fabe149d5e50450ee7",
  pinterestUrl: "https://www.pinterest.com/",
  cleveUrl: "https://app.cleve.ai",                       // opens in a new tab (or press C)
  meetLink: "https://calendar.notion.com/meet/nathanieltham/meet",   // copied by "Copy meeting link" (or press M)
  notionCalendarUrl: "https://calendar.notion.so",
  calendarIcsUrls: [],           // optional: secret iCal links; you can also paste them on the page
  clock24h: false,               // true = 24-hour clock
  maxQuoteLength: 160,
  cities: [
    { label: "Vancouver",    zone: "America/Vancouver" },
    { label: "Kuala Lumpur", zone: "Asia/Kuala_Lumpur" },
    { label: "Copenhagen",   zone: "Europe/Copenhagen" }
  ],
  // Add more images to /assets and list them here. "position" is the CSS background-position.
  backgrounds: [
    { file: "assets/clouds.webp", position: "center 60%" }
  ],
  // Retro pan: the picture updates only `fps` times a second and holds still in between.
  retro: {
    fps: 6,            // 6 = one change every 10 frames on a 60Hz screen
    panSeconds: 684,    // time to pan one way before reversing (higher = slower)
    weavePx: 1,        // random film-gate jitter per step
    flicker: 0.02      // random brightness change per step (0 = off)
  }
};
